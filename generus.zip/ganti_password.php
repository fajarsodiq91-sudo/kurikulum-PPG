<?php

session_start();

include 'config.php';

if(!isset($_SESSION['login'])){

    die("Harus login");
}

include 'templates/header.php';

if(isset($_POST['ganti'])){

    $passwordLama =
    $_POST['password_lama'];

    $passwordBaru =
    trim($_POST['password_baru']);

    $konfirmasi =
    trim($_POST['konfirmasi']);

    $idUser =
    intval($_SESSION['id']);
    
    echo $idUser;

    $query =
    mysqli_query($conn,

    "SELECT * FROM users
    WHERE id=$idUser");

    $user =
    mysqli_fetch_assoc($query);

    if(
    trim($passwordLama)
    !=
    trim($user['password'])
    ){

        echo '

        <div class="alert alert-danger">

        Password lama salah

        </div>

        ';

    } elseif($passwordBaru !=
    $konfirmasi){

        echo '

        <div class="alert alert-danger">

        Konfirmasi password tidak cocok

        </div>

        ';

    } else {

        mysqli_query($conn,

    "UPDATE users
    SET password='$passwordBaru'
    WHERE id=$idUser");

        echo '

        <div class="alert alert-success">

        Password berhasil diganti

        </div>

        ';
    }
}
?>

<div class="container mt-4">

<div class="card shadow">

<div class="card-body">

<h3 class="mb-4">

Ganti Password

</h3>

<form method="POST">

<div class="mb-3">

<label>
Password Lama
</label>

<input
type="password"
name="password_lama"
class="form-control"
required>

</div>

<div class="mb-3">

<label>
Password Baru
</label>

<input
type="password"
name="password_baru"
class="form-control"
required>

</div>

<div class="mb-3">

<label>
Konfirmasi Password Baru
</label>

<input
type="password"
name="konfirmasi"
class="form-control"
required>

</div>

<button
type="submit"
name="ganti"
class="btn btn-primary">

Ganti Password

</button>

<a href="dashboard.php"
class="btn btn-secondary">

Kembali

</a>

</form>

</div>

</div>

</div>

<?php
include 'templates/footer.php';
?>