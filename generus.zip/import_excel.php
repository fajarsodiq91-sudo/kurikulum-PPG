<?php

session_start();

include 'config.php';

if($_SESSION['role'] != 'master'){

    die("Tidak punya akses");
}

include 'templates/header.php';

$berhasil = 0;
$gagal = 0;

if(isset($_POST['import'])){

    set_time_limit(0);

    $file =
    $_FILES['file']['tmp_name'];

    $handle = fopen($file, "r");

    // skip header csv
    fgetcsv($handle);

    while(($data = fgetcsv(
        $handle,
        10000,
        ","
    )) !== FALSE){

        // total kolom wajib 21
        if(count($data) < 21){

            $gagal++;
            continue;
        }

        $nomor =
        mysqli_real_escape_string(
        $conn,
        $data[0]
        );

        $desa =
        mysqli_real_escape_string(
        $conn,
        $data[1]
        );

        $kelompok =
        mysqli_real_escape_string(
        $conn,
        $data[2]
        );

        $madrasah =
        mysqli_real_escape_string(
        $conn,
        $data[3]
        );

        $nis =
        mysqli_real_escape_string(
        $conn,
        $data[4]
        );

        $nama_bapak =
        mysqli_real_escape_string(
        $conn,
        $data[5]
        );

        $nama_ibu =
        mysqli_real_escape_string(
        $conn,
        $data[6]
        );

        $pekerjaan_bapak =
        mysqli_real_escape_string(
        $conn,
        $data[7]
        );

        $pekerjaan_ibu =
        mysqli_real_escape_string(
        $conn,
        $data[8]
        );

        $nomor_wa =
        mysqli_real_escape_string(
        $conn,
        $data[9]
        );

        $nama_santri =
        mysqli_real_escape_string(
        $conn,
        $data[10]
        );

        $jenis_kelamin =
        mysqli_real_escape_string(
        $conn,
        $data[11]
        );

        $kota_lahir =
        mysqli_real_escape_string(
        $conn,
        $data[12]
        );

        $tanggal_lahir =
        mysqli_real_escape_string(
        $conn,
        $data[13]
        );

        $anak_ke =
        mysqli_real_escape_string(
        $conn,
        $data[14]
        );

        $dari_saudara =
        mysqli_real_escape_string(
        $conn,
        $data[15]
        );

        $kelas_sekolah =
        mysqli_real_escape_string(
        $conn,
        $data[16]
        );

        $kelas_kbm =
        mysqli_real_escape_string(
        $conn,
        $data[17]
        );

        $jenjang_generus =
        mysqli_real_escape_string(
        $conn,
        $data[18]
        );

        $status_generus =
        mysqli_real_escape_string(
        $conn,
        $data[19]
        );

        $keterangan =
        mysqli_real_escape_string(
        $conn,
        $data[20]
        );

        $query = mysqli_query($conn,

        "INSERT INTO generus(

        nomor,
        desa,
        kelompok,
        madrasah,
        nis,
        nama_bapak,
        nama_ibu,
        pekerjaan_bapak,
        pekerjaan_ibu,
        nomor_wa,
        nama_santri,
        jenis_kelamin,
        kota_lahir,
        tanggal_lahir,
        anak_ke,
        dari_saudara,
        kelas_sekolah,
        kelas_kbm,
        jenjang_generus,
        status_generus,
        keterangan

        ) VALUES (

        '$nomor',
        '$desa',
        '$kelompok',
        '$madrasah',
        '$nis',
        '$nama_bapak',
        '$nama_ibu',
        '$pekerjaan_bapak',
        '$pekerjaan_ibu',
        '$nomor_wa',
        '$nama_santri',
        '$jenis_kelamin',
        '$kota_lahir',
        '$tanggal_lahir',
        '$anak_ke',
        '$dari_saudara',
        '$kelas_sekolah',
        '$kelas_kbm',
        '$jenjang_generus',
        '$status_generus',
        '$keterangan'
        )");

        if($query){

            $berhasil++;

        } else {

            $gagal++;
        }
    }

    fclose($handle);

    echo '

    <div class="alert alert-success">

    Import selesai

    <br><br>

    Berhasil:
    <b>'.$berhasil.'</b>

    <br>

    Gagal:
    <b>'.$gagal.'</b>

    </div>

    ';
}
?>

<div class="card shadow">

<div class="card-body">

<h3 class="mb-4">

Import CSV Generus

</h3>

<div class="alert alert-info">

Upload file CSV UTF-8

</div>

<form method="POST"
enctype="multipart/form-data">

<div class="mb-3">

<input type="file"
name="file"
class="form-control"
required>

</div>

<button type="submit"
name="import"
class="btn btn-primary">

Import CSV

</button>

<a href="data_generus.php"
class="btn btn-secondary">

Kembali

</a>

</form>

</div>

</div>

<?php
include 'templates/footer.php';
?>