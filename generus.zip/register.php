<?php
include 'config.php';

if(isset($_POST['register'])){

    $nama = $_POST['nama'];

    $username = $_POST['username'];

    $password = $_POST['password'];

    $role = $_POST['role'];

    $desa = $_POST['desa'];

    $kelompok = $_POST['kelompok'];
    if($role == 'pjp_kelompok' && empty($kelompok)){

    die("Kelompok wajib dipilih untuk PJP Kelompok");

}

    mysqli_query($conn, "INSERT INTO users

    (nama,username,password,role,desa,kelompok)

    VALUES

    ('$nama','$username','$password',
    '$role','$desa','$kelompok')
    ");

    $success = "Pendaftaran berhasil.
    Tunggu approval master.";
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Register</title>

<link href=
"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body class="bg-light">

<div class="container-fluid min-vh-100">

<div class="row justify-content-center align-items-center py-4">

<div class="col-md-5">

<div class="card shadow-lg border-0 rounded-4">

<div class="card-body p-4">

<h3 class="text-center mb-4">
Register
</h3>

<?php if(isset($success)){ ?>

<div class="alert alert-success">

<?php echo $success; ?>

</div>

<?php } ?>

<form method="POST">

<div class="mb-3">

<label>Nama</label>

<input type="text"
name="nama"
class="form-control">

</div>

<div class="mb-3">

<label>Username</label>

<input type="text"
name="username"
class="form-control">

</div>

<div class="mb-3">

<label>Password</label>

<input type="password"
name="password"
class="form-control">

</div>

<div class="mb-3">

<label>Role</label>

<select name="role" id="role" class="form-control" onchange="toggleKelompok()">

<option value="pjp_desa">
PJP Desa
</option>

<option value="pjp_kelompok">
PJP Kelompok
</option>

</select>

</div>

<div class="mb-3">

<label>Desa</label>

<select
name="desa"
id="desa"
class="form-control"
onchange="updateKelompok()">

<option value="">
Pilih Desa
</option>

<option value="Adiarsa Timur">
Adiarsa Timur
</option>

<option value="Klari">
Klari
</option>

<option value="Lemah Mulya">
Lemah Mulya
</option>

<option value="Tunggak Jati">
Tunggak Jati
</option>

</select>

</div>

<div class="mb-3" id="kelompokDiv">

<label>
Kelompok
</label>

<select
name="kelompok"
id="kelompok"
class="form-control">

<option value="">
Pilih Kelompok
</option>

</select>

</div>

<button type="submit"
name="register"
class="btn btn-primary w-100">

Daftar

</button>

</form>

<hr>

<a href="login.php"
class="btn btn-secondary w-100">

Kembali Login

</a>

</div>

</div>

</div>

</div>

</div>

<script>

function updateKelompok(){

    let desa =
    document.getElementById("desa").value;

    let kelompok =
    document.getElementById("kelompok");

    let data = {

        "Adiarsa Timur": [
            "Babakan Jati 1",
            "Babakan Jati 2",
            "Karawang Kota 1",
            "Karawang Kota 2",
            "Wadas",
            "Wirasaba"
        ],

        "Klari": [
            "Belendung",
            "Cibalongsari 1",
            "Cibalongsari 2",
            "Cirejag",
            "Kalimulya",
            "Pancawati"
        ],

        "Lemah Mulya": [
            "Anggadita",
            "CKM 1",
            "CKM 2",
            "HNH",
            "Tamiang 1",
            "Tamiang 2",
            "Karawang Megah",
            "Tipar"
        ],

        "Tunggak Jati": [
            "Kalang Surya",
            "Pakis",
            "Tanjung Baru Barat",
            "Tanjung Baru Timur",
            "Tunggak Jati"
        ]
    };

    kelompok.innerHTML =
    '<option value="">Pilih Kelompok</option>';

    if(data[desa]){

        data[desa].forEach(function(item){

            let option =
            document.createElement("option");

            option.value = item;

            option.text = item;

            kelompok.appendChild(option);

        });
    }
}

function toggleKelompok(){

    let role =
    document.getElementById("role").value;

    let kelompokDiv =
    document.getElementById("kelompokDiv");

    if(role == 'pjp_desa'){

        kelompokDiv.style.display = 'none';

    } else {

        kelompokDiv.style.display = 'block';
    }
}

toggleKelompok();

</script>

</body>
</html>