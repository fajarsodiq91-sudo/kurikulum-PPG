<?php

session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'templates/header.php';

if(!isset($_SESSION['login'])){

    die("Harus login");

}
include 'config.php';

$id = $_GET['id'];

$query = mysqli_query($conn,
"SELECT * FROM generus WHERE id='$id'");

$data = mysqli_fetch_assoc($query);
$role = $_SESSION['role'];

if($role == 'pjp_desa'){

    if($data['desa'] != $_SESSION['desa']){

        die("Tidak punya akses");
    }
}

if($role == 'pjp_kelompok'){

    if($data['kelompok']
    != $_SESSION['kelompok']){

        die("Tidak punya akses");
    }
}

$role = $_SESSION['role'];

if($role == 'pjp_kelompok'){

    if($data['kelompok'] != $_SESSION['kelompok']){

        die("Tidak punya akses");

    }
}

if($role == 'pjp_desa'){

    if($data['desa'] != $_SESSION['desa']){

        die("Tidak punya akses");

    }
}

if(isset($_POST['update'])){


    $desa = $_POST['desa'];
    $kelompok = $_POST['kelompok'];
    $madrasah = $_POST['madrasah'];

    $nama_bapak = $_POST['nama_bapak'];
    $nama_ibu = $_POST['nama_ibu'];

    $pekerjaan_bapak = $_POST['pekerjaan_bapak'];
    $pekerjaan_ibu = $_POST['pekerjaan_ibu'];

    $nomor_wa = $_POST['nomor_wa'];

    $nama_santri = $_POST['nama_santri'];

    $jenis_kelamin = $_POST['jenis_kelamin'];

    $kota_lahir = $_POST['kota_lahir'];

    $tanggal_lahir = $_POST['tanggal_lahir'];

    $anak_ke = $_POST['anak_ke'];

    $dari_saudara = $_POST['dari_saudara'];

    $kelas_sekolah = $_POST['kelas_sekolah'];

    $kelas_kbm = $_POST['kelas_kbm'];
    
    $jenjang_generus = $_POST['jenjang_generus'];

    $status_generus = $_POST['status_generus'];
    
    $keterangan = $_POST['keterangan'];

    mysqli_query($conn,

    "UPDATE generus SET

    desa='$desa',
    kelompok='$kelompok',
    madrasah='$madrasah',

    nama_bapak='$nama_bapak',
    nama_ibu='$nama_ibu',

    pekerjaan_bapak='$pekerjaan_bapak',
    pekerjaan_ibu='$pekerjaan_ibu',

    nomor_wa='$nomor_wa',

    nama_santri='$nama_santri',

    jenis_kelamin='$jenis_kelamin',

    kota_lahir='$kota_lahir',

    tanggal_lahir='$tanggal_lahir',

    anak_ke='$anak_ke',

    dari_saudara='$dari_saudara',

    kelas_sekolah='$kelas_sekolah',

    kelas_kbm='$kelas_kbm',
    
    jenjang_generus='$jenjang_generus',

    status_generus='$status_generus',
    
    keterangan='$keterangan'

    WHERE id='$id'
    ");

    header("Location: data_generus.php");
}
?>

<h2>Edit Data</h2>

<form method="POST">

Desa <span class="text-danger">*</span> <br>
<select
name="desa"
id="desa"
class="form-control"
onchange="updateKelompok()" required>

<option value="Adiarsa Timur"

<?php
if($data['desa'] == 'Adiarsa Timur'){
    echo 'selected';
}
?>

>

Adiarsa Timur

</option>

<option value="Klari"

<?php
if($data['desa'] == 'Klari'){
    echo 'selected';
}
?>

>

Klari

</option>

<option value="Lemah Mulya"

<?php
if($data['desa'] == 'Lemah Mulya'){
    echo 'selected';
}
?>

>

Lemah Mulya

</option>

<option value="Tunggak Jati"

<?php
if($data['desa'] == 'Tunggak Jati'){
    echo 'selected';
}
?>

>

Tunggak Jati

</option>

</select>

<br><br>

<div class="mb-3">

<label>
Kelompok
<span class="text-danger">*</span>
</label>

<select
name="kelompok"
id="kelompok"
class="form-control" required>

</select>

</div>

Madrasah<br>
<input type="text" name="madrasah" class="form-control" value="<?php echo $data['madrasah']; ?>">

<br><br>

Nama Bapak<br>
<input type="text" name="nama_bapak" class="form-control" value="<?php echo $data['nama_bapak']; ?>">

<br><br>

Nama Ibu<br>
<input type="text" name="nama_ibu" class="form-control" value="<?php echo $data['nama_ibu']; ?>">

<br><br>

Pekerjaan Bapak<br>
<input type="text" name="pekerjaan_bapak" class="form-control" value="<?php echo $data['pekerjaan_bapak']; ?>">

<br><br>

Pekerjaan Ibu<br>
<input type="text" name="pekerjaan_ibu" class="form-control" value="<?php echo $data['pekerjaan_ibu']; ?>">

<br><br>

Nomor WA<br>
<input type="text" name="nomor_wa" class="form-control" value="<?php echo $data['nomor_wa']; ?>">

<br><br>

Nama Santri <span class="text-danger">*</span> <br>

<input type="text" name="nama_santri" class="form-control" required value="<?php echo $data['nama_santri']; ?>">

<br><br>

Jenis Kelamin <span class="text-danger">*</span> <br>
<select name="jenis_kelamin" class="form-control" value="<?php echo $data['jenis_kelamin']; ?>">

<option value="Laki-Laki"
<?php
if($data['jenis_kelamin'] == 'Laki-Laki'){
    echo 'selected';
}
?>

>

Laki-Laki

</option>

<option value="Perempuan"
<?php
if($data['jenis_kelamin'] == 'Perempuan'){
    echo 'selected';
}
?>

>

Perempuan

</option>

</select>

<br><br>

Kota Lahir<br>
<input type="text" name="kota_lahir" class="form-control"  value="<?php echo $data['kota_lahir']; ?>">
<br><br>

Tanggal Lahir<br>
<input type="date" name="tanggal_lahir" class="form-control" value="<?php echo $data['tanggal_lahir']; ?>">
<br><br>


Anak ke<br>
<input type="number" name="anak_ke" class="form-control" value="<?php echo $data['anak_ke']; ?>">
<br><br>

Dari Berapa Saudara<br>
<input type="number" name="dari_saudara" class="form-control" value="<?php echo $data['dari_saudara']; ?>">
<br><br>

<div class="mb-3">

<label>
Kelas Sekolah
<span class="text-danger">*</span>
</label>

<select
name="kelas_sekolah"
class="form-control" required>

<option value="Pra PAUD"
<?php if($data['kelas_sekolah']=='Pra PAUD'){echo 'selected';} ?>>
Pra PAUD
</option>

<option value="PAUD"
<?php if($data['kelas_sekolah']=='PAUD'){echo 'selected';} ?>>
PAUD
</option>

<option value="TK"
<?php if($data['kelas_sekolah']=='TK'){echo 'selected';} ?>>
TK
</option>

<option value="1"
<?php if($data['kelas_sekolah']=='1'){echo 'selected';} ?>>
1
</option>

<option value="2"
<?php if($data['kelas_sekolah']=='2'){echo 'selected';} ?>>
2
</option>

<option value="3"
<?php if($data['kelas_sekolah']=='3'){echo 'selected';} ?>>
3
</option>

<option value="4"
<?php if($data['kelas_sekolah']=='4'){echo 'selected';} ?>>
4
</option>

<option value="5"
<?php if($data['kelas_sekolah']=='5'){echo 'selected';} ?>>
5
</option>

<option value="6"
<?php if($data['kelas_sekolah']=='6'){echo 'selected';} ?>>
6
</option>

<option value="7"
<?php if($data['kelas_sekolah']=='7'){echo 'selected';} ?>>
7
</option>

<option value="8"
<?php if($data['kelas_sekolah']=='8'){echo 'selected';} ?>>
8
</option>

<option value="9"
<?php if($data['kelas_sekolah']=='9'){echo 'selected';} ?>>
9
</option>

<option value="10"
<?php if($data['kelas_sekolah']=='10'){echo 'selected';} ?>>
10
</option>

<option value="11"
<?php if($data['kelas_sekolah']=='11'){echo 'selected';} ?>>
11
</option>

<option value="12"
<?php if($data['kelas_sekolah']=='12'){echo 'selected';} ?>>
12
</option>

<option value="Mahasiswa"
<?php if($data['kelas_sekolah']=='Mahasiswa'){echo 'selected';} ?>>
Mahasiswa
</option>

<option value="-"
<?php if($data['kelas_sekolah']=='-'){echo 'selected';} ?>>
-
</option>

</select>

</div>

<div class="mb-3">

<label>
Kelas KBM
<span class="text-danger">*</span>
</label>

<select name="kelas_kbm" class="form-control" required>

<option value="Pra PAUD"
<?php if($data['kelas_kbm']=='Pra PAUD'){echo 'selected';} ?>>
Pra PAUD
</option>

<option value="PAUD"
<?php if($data['kelas_kbm']=='PAUD'){echo 'selected';} ?>>
PAUD
</option>

<option value="1"
<?php if($data['kelas_kbm']=='1'){echo 'selected';} ?>>
1
</option>

<option value="2"
<?php if($data['kelas_kbm']=='2'){echo 'selected';} ?>>
2
</option>

<option value="3"
<?php if($data['kelas_kbm']=='3'){echo 'selected';} ?>>
3
</option>

<option value="4"
<?php if($data['kelas_kbm']=='4'){echo 'selected';} ?>>
4
</option>

<option value="5"
<?php if($data['kelas_kbm']=='5'){echo 'selected';} ?>>
5
</option>

<option value="6"
<?php if($data['kelas_kbm']=='6'){echo 'selected';} ?>>
6
</option>

<option value="7"
<?php if($data['kelas_kbm']=='7'){echo 'selected';} ?>>
7
</option>

<option value="8"
<?php if($data['kelas_kbm']=='8'){echo 'selected';} ?>>
8
</option>

<option value="9"
<?php if($data['kelas_kbm']=='9'){echo 'selected';} ?>>
9
</option>

<option value="10"
<?php if($data['kelas_kbm']=='10'){echo 'selected';} ?>>
10
</option>

<option value="11"
<?php if($data['kelas_kbm']=='11'){echo 'selected';} ?>>
11
</option>

<option value="12"
<?php if($data['kelas_kbm']=='12'){echo 'selected';} ?>>
12
</option>

<option value="Pra Nikah"
<?php if($data['kelas_kbm']=='Pra Nikah'){echo 'selected';} ?>>
Pra Nikah
</option>

</select>

</div>

<div class="mb-3">

<label>
Jenjang Generus
<span class="text-danger">*</span>
</label>

<select name="jenjang_generus" class="form-control" required>

<option value="Pra PAUD"
<?php if($data['jenjang_generus']=='Pra PAUD'){echo 'selected';} ?>>
Pra PAUD
</option>

<option value="PAUD"
<?php if($data['jenjang_generus']=='PAUD'){echo 'selected';} ?>>
PAUD
</option>

<option value="Caberawit"
<?php if($data['jenjang_generus']=='Caberawit'){echo 'selected';} ?>>
Caberawit
</option>

<option value="Pra Remaja"
<?php if($data['jenjang_generus']=='Pra Remaja'){echo 'selected';} ?>>
Pra Remaja
</option>

<option value="Remaja"
<?php if($data['jenjang_generus']=='Remaja'){echo 'selected';} ?>>
Remaja
</option>

<option value="Pra Nikah"
<?php if($data['jenjang_generus']=='Pra Nikah'){echo 'selected';} ?>>
Pra Nikah
</option>

</select>

</div>

<div class="mb-3">

<label>
Status Generus
<span class="text-danger">*</span>
</label>

<select name="status_generus" class="form-control" required>

<option value="Masih Generus"
<?php if($data['status_generus']=='Masih Generus'){echo 'selected';} ?>>
Masih Generus
</option>

<option value="Pindah Sambung"
<?php if($data['status_generus']=='Pindah Sambung'){echo 'selected';} ?>>
Pindah Sambung
</option>

<option value="Sudah Menikah"
<?php if($data['status_generus']=='Sudah Menikah'){echo 'selected';} ?>>
Sudah Menikah
</option>

</select>

</div>

Ketarangan<br>
<input type="text" name="keterangan" class="form-control"  value="<?php echo $data['keterangan']; ?>">
<br><br>

<button type="submit"
name="update"
class="btn btn-primary">
    
Update

</button>

<a href="data_generus.php"
class="btn btn-secondary">

Kembali Dashboard

</a>

</form>

<script>

let dataKelompok = {

    "Adiarsa Timur": [
        "Babakan Jati 1",
        "Babakan Jati 2",
        "Karawang Kota 1",
        "Karawang Kota 2",
        "Wadas",
        "Wirasaba"
    ],

    "Klari": [
        "Belendung",
        "Cibalongsari 1",
        "Cibalongsari 2",
        "Cirejag",
        "Kalimulya",
        "Pancawati"
    ],

    "Lemah Mulya": [
        "Anggadita",
        "CKM 1",
        "CKM 2",
        "HNH",
        "Tamiang 1",
        "Tamiang 2",
        "Karawang Megah",
        "Tipar"
    ],

    "Tunggak Jati": [
        "Kalang Surya",
        "Pakis",
        "Tanjung Baru Barat",
        "Tanjung Baru Timur",
        "Tunggak Jati"
    ]
};

function updateKelompok(){

    let desa =
    document.getElementById("desa").value;

    let kelompokSelect =
    document.getElementById("kelompok");

    let selectedKelompok =
    "<?php echo $data['kelompok']; ?>";

    kelompokSelect.innerHTML = "";

    if(dataKelompok[desa]){

        dataKelompok[desa].forEach(function(item){

            let option =
            document.createElement("option");

            option.value = item;

            option.text = item;

            if(item == selectedKelompok){

                option.selected = true;
            }

            kelompokSelect.appendChild(option);

        });
    }
}

updateKelompok();

</script>

<?php
include 'templates/footer.php';
?>