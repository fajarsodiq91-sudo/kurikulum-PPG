<!DOCTYPE html>
<html>
<head>

    <title>Generus PPG Karawang Timur</title>

    <meta charset="UTF-8">

    <meta name="viewport"
    content="width=device-width, initial-scale=1">

    <link href=
    "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet">

<link rel="stylesheet"

href=
"https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css">

</head>

<body>

<style>

.main-wrapper{

    width:100%;

    max-width:1800px;

    margin:auto;
}

</style>

<div class="main-wrapper">
    
<nav class="navbar navbar-dark bg-dark">

<div class="container-fluid">

<span class="navbar-brand mb-0 h1">
Generus PPG Karawang Timur
</span>

</div>

</nav>

<div class="container-fluid px-3 py-3">