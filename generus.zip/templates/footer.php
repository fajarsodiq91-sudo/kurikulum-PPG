</div>

<script src=
"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

<script src=
"https://code.jquery.com/jquery-3.7.1.min.js">
</script>

<script src=
"https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js">
</script>

<script src=
"https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js">
</script>

<script>

$(document).ready(function(){

    $('#tabelGenerus').DataTable({

        pageLength: 10,

        lengthMenu: [

            [10,25,50,100],
            [10,25,50,100]

        ],

        paging: true,

        pagingType: "full_numbers",

        searching: true,

        ordering: true,

        info: true,

        responsive: false,

        autoWidth: false,

        scrollX: true,

        order: [[10, 'asc']],

        language: {

            search:
            "Cari:",

            lengthMenu:
            "Tampilkan _MENU_ data",

            info:
            "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",

            paginate: {

                first: "Awal",

                last: "Akhir",

                next: "Berikutnya",

                previous: "Sebelumnya"
            }
        }
    });

});

</script>

<button
onclick="scrollToTop()"

id="btnTop"

class="btn btn-primary"

style="

position:fixed;
bottom:20px;
right:20px;
display:none;
z-index:999;

">

↑

</button>

<script>

window.onscroll = function(){

    let btn =
    document.getElementById("btnTop");

    if(document.body.scrollTop > 300 ||

    document.documentElement.scrollTop > 300){

        btn.style.display = "block";

    } else {

        btn.style.display = "none";
    }
};

function scrollToTop(){

    window.scrollTo({

        top:0,
        behavior:'smooth'
    });
}

</script>
</div>
</body>
</html>