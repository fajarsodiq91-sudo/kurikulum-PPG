<?php

session_start();

include 'config.php';

$id =
$_GET['id'] ?? 0;

$query =
mysqli_query($conn,

"SELECT *

FROM generus

WHERE id='$id'

LIMIT 1");

$querySetting =
mysqli_query($conn,

"SELECT *

FROM setting_app

LIMIT 1");

$setting =
mysqli_fetch_assoc(
$querySetting
);

$semester =
$setting['semester_aktif'];

$data =
mysqli_fetch_assoc($query);

if(!$data){

    die("Data tidak ditemukan");
}

$queryAkhlaq =
mysqli_query($conn,

"SELECT
AVG(nilai) as rata

FROM nilai_munaqosah

WHERE

nis='".$data['nis']."'

AND semester='$semester'

AND kategori='Akhlaq'
");

$akhlaq =
round(
mysqli_fetch_assoc(
$queryAkhlaq
)['rata'],
2
);

$queryKemandirian =
mysqli_query($conn,

"SELECT
AVG(nilai) as rata

FROM nilai_munaqosah

WHERE

nis='".$data['nis']."'

AND semester='$semester'

AND kategori='Kemandirian'
");

$kemandirian =
round(
mysqli_fetch_assoc(
$queryKemandirian
)['rata'],
2
);

$queryBaca =
mysqli_query($conn,

"SELECT
AVG(nilai) as rata

FROM nilai_munaqosah

WHERE

nis='".$data['nis']."'

AND semester='$semester'

AND kategori='Bacaan'
");

$baca =
round(
mysqli_fetch_assoc(
$queryBaca
)['rata'],
2
);

$queryTulis =
mysqli_query($conn,

"SELECT
AVG(nilai) as rata

FROM nilai_munaqosah

WHERE

nis='".$data['nis']."'

AND semester='$semester'

AND kategori='Tulis'
");

$menulis =
round(
mysqli_fetch_assoc(
$queryTulis
)['rata'],
2
);

$queryHafalan =
mysqli_query($conn,

"SELECT
AVG(nilai) as rata

FROM nilai_munaqosah

WHERE

nis='".$data['nis']."'

AND semester='$semester'

AND kategori IN(

'Hafalan Dalil',
'Hafalan Doa-doa Harian',
'Hafalan Surat-surat Al Quran'

)
");

$hafalan =
round(
mysqli_fetch_assoc(
$queryHafalan
)['rata'],
2
);

$queryPraktik =
mysqli_query($conn,

"SELECT
AVG(nilai) as rata

FROM nilai_munaqosah

WHERE

nis='".$data['nis']."'

AND semester='$semester'

AND kategori IN(

'Faham Al Quran dan Hadits',
'Keilmuan',
'Kemandirian Pribadi',
'Praktik Ibadah'

)
");

$praktik =
round(
mysqli_fetch_assoc(
$queryPraktik
)['rata'],
2
);

$nilaiAkhir =
round(

(
$akhlaq +
$baca +
$hafalan +
$menulis +
$praktik +
$kemandirian
)
/ 6

,2);

<h2>Preview Rapor</h2>

<hr>

Nama :
<?php echo $data['nama_santri']; ?>

<br>

NIS :
<?php echo $data['nis']; ?>

<hr>

<table border="1"
cellpadding="8">

<tr>

<td>
Akhlaqul Karimah
</td>

<td>
<?php echo $akhlaq; ?>
</td>

</tr>

<tr>

<td>
Baca
</td>

<td>
<?php echo $baca; ?>
</td>

</tr>

<tr>

<td>
Hafalan
</td>

<td>
<?php echo $hafalan; ?>
</td>

</tr>

<tr>

<td>
Menulis
</td>

<td>
<?php echo $menulis; ?>
</td>

</tr>

<tr>

<td>
Praktik Ibadah
</td>

<td>
<?php echo $praktik; ?>
</td>

</tr>

<tr>

<td>
Kemandirian
</td>

<td>
<?php echo $kemandirian; ?>
</td>

</tr>

<tr>

<td>
Nilai Akhir
</td>

<td>

<b>
<?php echo $nilaiAkhir; ?>
</b>

</td>

</tr>

</table>