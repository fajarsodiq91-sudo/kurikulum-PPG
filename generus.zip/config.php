<?php

$host = "localhost";
$user = "u627878615_db_user_ppg";
$pass = "Fadi@179179";
$db   = "u627878615_db_generus_ppg";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal");
}

?>