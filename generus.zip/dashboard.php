<?php
session_start();
$role =
$_SESSION['role'] ?? 'viewer';
include 'config.php';

include 'templates/header.php';
$filterJK =
$_GET['jenis_kelamin'] ?? '';

$filterStatus =
$_GET['status_generus'] ?? 'Masih Generus';
$where = "WHERE 1=1";

if(!empty($filterJK)){

    $where .= "
    AND jenis_kelamin='$filterJK'
    ";
}

if(!empty($filterStatus)){

    $where .= "
    AND status_generus='$filterStatus'
    ";
}
$queryRekap = mysqli_query($conn,

"SELECT

desa,
kelompok,

SUM(
CASE
WHEN kelas_kbm='Pra PAUD'
THEN 1 ELSE 0
END
) as prapaud,

SUM(
CASE
WHEN kelas_kbm='PAUD'
THEN 1 ELSE 0
END
) as paud,

SUM(
CASE
WHEN kelas_kbm='1'
THEN 1 ELSE 0
END
) as kelas1,

SUM(
CASE
WHEN kelas_kbm='2'
THEN 1 ELSE 0
END
) as kelas2,

SUM(
CASE
WHEN kelas_kbm='3'
THEN 1 ELSE 0
END
) as kelas3,

SUM(
CASE
WHEN kelas_kbm='4'
THEN 1 ELSE 0
END
) as kelas4,

SUM(
CASE
WHEN kelas_kbm='5'
THEN 1 ELSE 0
END
) as kelas5,

SUM(
CASE
WHEN kelas_kbm='6'
THEN 1 ELSE 0
END
) as kelas6,

SUM(
CASE
WHEN kelas_kbm='7'
THEN 1 ELSE 0
END
) as kelas7,

SUM(
CASE
WHEN kelas_kbm='8'
THEN 1 ELSE 0
END
) as kelas8,

SUM(
CASE
WHEN kelas_kbm='9'
THEN 1 ELSE 0
END
) as kelas9,

SUM(
CASE
WHEN kelas_kbm='10'
THEN 1 ELSE 0
END
) as kelas10,

SUM(
CASE
WHEN kelas_kbm='11'
THEN 1 ELSE 0
END
) as kelas11,

SUM(
CASE
WHEN kelas_kbm='12'
THEN 1 ELSE 0
END
) as kelas12,

SUM(
CASE
WHEN kelas_kbm='Pra Nikah'
THEN 1 ELSE 0
END
) as pranikah,

COUNT(*) as total_generus

FROM generus

$where

GROUP BY desa, kelompok

ORDER BY desa, kelompok
");
?>

<div class="card">

<div class="card-body">

<h3>
Dashboard Generus

</h3>

<p>
Login sebagai:
<b>
<?php echo $role; ?>
</b>
</p>

<hr>

<div class="d-grid gap-2">

<?php
if($role != 'viewer'){
?>

<div class="d-grid gap-2 d-md-flex flex-wrap mb-4">
    
<a href="munaqosah.php"
class="btn btn-dark">

Dashboard Munaqosah

</a>

<a href="tambah_generus.php"
class="btn btn-primary">

Tambah Data Generus

</a>

<?php } ?>

<a href="data_generus.php"
class="btn btn-success">

Lihat Database

</a>

<?php
if($role == 'master'){
?>

<a href="approval_user.php"
class="btn btn-warning">

Approval User

</a>

<?php } ?>

<?php
if($role != 'viewer'){
?>

<a href="ganti_password.php"
class="btn btn-warning">

Ganti Password

</a>

<?php } ?>

<?php
if($role == 'master'){
?>

<a href="update_massal.php"
class="btn btn-dark">

Update Massal

</a>

<?php } ?>

<a href="logout.php"
class="btn btn-danger">

Logout

</a>

</div>

</div>

</div>

</div>

<br><br>

<div class="card shadow">

<div class="card-body">

<h4 class="mb-4">

Rekap Jumlah Generus

<form method="GET">

<div class="row mb-4">

<div class="col-md-3 mb-2">

<select
name="jenis_kelamin"
class="form-control">

<option value="">
Semua Jenis Kelamin
</option>

<option value="Laki-Laki"

<?php
if($filterJK ==
'Laki-Laki'){
echo 'selected';
}
?>

>

Laki-Laki

</option>

<option value="Perempuan"

<?php
if($filterJK ==
'Perempuan'){
echo 'selected';
}
?>

>

Perempuan

</option>

</select>

</div>

<div class="col-md-3 mb-2">

<select
name="status_generus"
class="form-control">

<option value="">
Semua Status
</option>

<option value="Masih Generus"

<?php
if($filterStatus ==
'Masih Generus'){
echo 'selected';
}
?>

>

Masih Generus

</option>

<option value="Pindah Sambung"

<?php
if($filterStatus ==
'Pindah Sambung'){
echo 'selected';
}
?>

>

Pindah Sambung

</option>

<option value="Sudah Menikah"

<?php
if($filterStatus ==
'Sudah Menikah'){
echo 'selected';
}
?>

>

Sudah Menikah

</option>

</select>

</div>

<div class="col-md-3 mb-2">

<button
type="submit"
class="btn btn-primary">

Filter

</button>

<a href="dashboard.php"
class="btn btn-secondary">

Reset

</a>

</div>

</div>

</form>

</h4>

<div class="table-responsive"
style="max-height:75vh;">

<table class="table table-bordered table-striped table-hover table-sm">

<tr class="table-dark">

<th>No</th>
<th>Desa</th>
<th>Kelompok</th>

<th>Pra PAUD</th>
<th>PAUD</th>

<th>1</th>
<th>2</th>
<th>3</th>
<th>4</th>
<th>5</th>
<th>6</th>
<th>7</th>
<th>8</th>
<th>9</th>
<th>10</th>
<th>11</th>
<th>12</th>

<th>Pra Nikah</th>

<th>Total Generus</th>

</tr>

<?php
$no = 1;

$desaSekarang = '';

$totalAllPraPaud = 0;
$totalAllPaud = 0;
$totalAll1 = 0;
$totalAll2 = 0;
$totalAll3 = 0;
$totalAll4 = 0;
$totalAll5 = 0;
$totalAll6 = 0;
$totalAll7 = 0;
$totalAll8 = 0;
$totalAll9 = 0;
$totalAll10 = 0;
$totalAll11 = 0;
$totalAll12 = 0;
$totalAllPraNikah = 0;
$totalAllGenerus = 0;

$totalDesaPraPaud = 0;
$totalDesaPaud = 0;
$totalDesa1 = 0;
$totalDesa2 = 0;
$totalDesa3 = 0;
$totalDesa4 = 0;
$totalDesa5 = 0;
$totalDesa6 = 0;
$totalDesa7 = 0;
$totalDesa8 = 0;
$totalDesa9 = 0;
$totalDesa10 = 0;
$totalDesa11 = 0;
$totalDesa12 = 0;
$totalDesaPraNikah = 0;
$totalDesaGenerus = 0;
while($rekap =

mysqli_fetch_assoc($queryRekap)){

if($desaSekarang != $rekap['desa']){

    // tampilkan total desa sebelumnya
    if($desaSekarang != ''){

        echo '

        <tr class="table-warning">

        <td colspan="3">

        <b>
        TOTAL '.$desaSekarang.'
        </b>

        </td>
        
        <td><b>'.$totalDesaPraPaud.'</b></td>
        <td><b>'.$totalDesaPaud.'</b></td>
        <td><b>'.$totalDesa1.'</b></td>
        <td><b>'.$totalDesa2.'</b></td>
        <td><b>'.$totalDesa3.'</b></td>
        <td><b>'.$totalDesa4.'</b></td>
        <td><b>'.$totalDesa5.'</b></td>
        <td><b>'.$totalDesa6.'</b></td>
        <td><b>'.$totalDesa7.'</b></td>
        <td><b>'.$totalDesa8.'</b></td>
        <td><b>'.$totalDesa9.'</b></td>
        <td><b>'.$totalDesa10.'</b></td>
        <td><b>'.$totalDesa11.'</b></td>
        <td><b>'.$totalDesa12.'</b></td>
        <td><b>'.$totalDesaPraNikah.'</b></td>

        <td>

        <b>
        '.$totalDesaGenerus.'
        </b>

        </td>

        </tr>

        ';
    }

    // reset subtotal desa
    $totalDesaPraPaud = 0;
    $totalDesaPaud = 0;
    $totalDesa1 = 0;
    $totalDesa2 = 0;
    $totalDesa3 = 0;
    $totalDesa4 = 0;
    $totalDesa5 = 0;
    $totalDesa6 = 0;
    $totalDesa7 = 0;
    $totalDesa8 = 0;
    $totalDesa9 = 0;
    $totalDesa10 = 0;
    $totalDesa11 = 0;
    $totalDesa12 = 0;
    $totalDesaPraNikah = 0;
    $totalDesaGenerus = 0;

    $desaSekarang = $rekap['desa'];

    echo '

    <tr class="table-primary">

    <td colspan="18">

    <b>
    DESA :
    '.$desaSekarang.'
    </b>

    </td>

    </tr>

    ';
}

$totalDesaPraPaud += $rekap['prapaud'];

$totalDesaPaud += $rekap['paud'];

$totalDesa1 += $rekap['kelas1'];

$totalDesa2 += $rekap['kelas2'];

$totalDesa3 += $rekap['kelas3'];

$totalDesa4 += $rekap['kelas4'];

$totalDesa5 += $rekap['kelas5'];

$totalDesa6 += $rekap['kelas6'];

$totalDesa7 += $rekap['kelas7'];

$totalDesa8 += $rekap['kelas8'];

$totalDesa9 += $rekap['kelas9'];

$totalDesa10 += $rekap['kelas10'];

$totalDesa11 += $rekap['kelas11'];

$totalDesa12 += $rekap['kelas12'];

$totalDesaPraNikah +=
$rekap['pranikah'];

$totalDesaGenerus +=
$rekap['total_generus'];

$totalAllPraPaud += $rekap['prapaud'];

$totalAllPaud += $rekap['paud'];

$totalAll1 += $rekap['kelas1'];

$totalAll2 += $rekap['kelas2'];

$totalAll3 += $rekap['kelas3'];

$totalAll4 += $rekap['kelas4'];

$totalAll5 += $rekap['kelas5'];

$totalAll6 += $rekap['kelas6'];

$totalAll7 += $rekap['kelas7'];

$totalAll8 += $rekap['kelas8'];

$totalAll9 += $rekap['kelas9'];

$totalAll10 += $rekap['kelas10'];

$totalAll11 += $rekap['kelas11'];

$totalAll12 += $rekap['kelas12'];

$totalAllPraNikah += $rekap['pranikah'];

$totalAllGenerus +=
$rekap['total_generus'];
?>

<tr>

<td>
<?php echo $no++; ?>
</td>

<td>
<?php echo $rekap['desa']; ?>
</td>

<td>
<?php echo $rekap['kelompok']; ?>
</td>

<td>
<?php echo $rekap['prapaud']; ?>
</td>

<td>
<?php echo $rekap['paud']; ?>
</td>

<td>
<?php echo $rekap['kelas1']; ?>
</td>

<td>
<?php echo $rekap['kelas2']; ?>
</td>

<td>
<?php echo $rekap['kelas3']; ?>
</td>

<td>
<?php echo $rekap['kelas4']; ?>
</td>

<td>
<?php echo $rekap['kelas5']; ?>
</td>

<td>
<?php echo $rekap['kelas6']; ?>
</td>

<td>
<?php echo $rekap['kelas7']; ?>
</td>

<td>
<?php echo $rekap['kelas8']; ?>
</td>

<td>
<?php echo $rekap['kelas9']; ?>
</td>

<td>
<?php echo $rekap['kelas10']; ?>
</td>

<td>
<?php echo $rekap['kelas11']; ?>
</td>

<td>
<?php echo $rekap['kelas12']; ?>
</td>

<td>
<?php echo $rekap['pranikah']; ?>
</td>

<td>
<b>
<?php echo $rekap['total_generus']; ?>
</b>
</td>

</tr>

<?php } ?>

<tr class="table-warning">

<td colspan="3">

<b>
TOTAL <?php echo $desaSekarang; ?>
</b>

</td>

<td><b><?php echo $totalDesaPraPaud; ?></b></td>

<td><b><?php echo $totalDesaPaud; ?></b></td>

<td><b><?php echo $totalDesa1; ?></b></td>

<td><b><?php echo $totalDesa2; ?></b></td>

<td><b><?php echo $totalDesa3; ?></b></td>

<td><b><?php echo $totalDesa4; ?></b></td>

<td><b><?php echo $totalDesa5; ?></b></td>

<td><b><?php echo $totalDesa6; ?></b></td>

<td><b><?php echo $totalDesa7; ?></b></td>

<td><b><?php echo $totalDesa8; ?></b></td>

<td><b><?php echo $totalDesa9; ?></b></td>

<td><b><?php echo $totalDesa10; ?></b></td>

<td><b><?php echo $totalDesa11; ?></b></td>

<td><b><?php echo $totalDesa12; ?></b></td>

<td><b><?php echo $totalDesaPraNikah; ?></b></td>

<td>

<b>
<?php echo $totalDesaGenerus; ?>
</b>

</td>

</tr>

<tr class="table-dark">

<td colspan="3">

<b>
TOTAL SELURUH
</b>

</td>

<td><b><?php echo $totalAllPraPaud; ?></b></td>

<td><b><?php echo $totalAllPaud; ?></b></td>

<td><b><?php echo $totalAll1; ?></b></td>

<td><b><?php echo $totalAll2; ?></b></td>

<td><b><?php echo $totalAll3; ?></b></td>

<td><b><?php echo $totalAll4; ?></b></td>

<td><b><?php echo $totalAll5; ?></b></td>

<td><b><?php echo $totalAll6; ?></b></td>

<td><b><?php echo $totalAll7; ?></b></td>

<td><b><?php echo $totalAll8; ?></b></td>

<td><b><?php echo $totalAll9; ?></b></td>

<td><b><?php echo $totalAll10; ?></b></td>

<td><b><?php echo $totalAll11; ?></b></td>

<td><b><?php echo $totalAll12; ?></b></td>

<td><b><?php echo $totalAllPraNikah; ?></b></td>

<td>

<b>

<?php echo $totalAllGenerus; ?>

</b>

</td>

</tr>

</table>

</div>

</div>

</div>
<?php
include 'templates/footer.php';
?>