<?php

session_start();

include 'config.php';

$role =
$_SESSION['role'] ?? 'viewer';

if($role == 'viewer'){

    die("Harus login");
}

$id =
$_GET['id']
?? 0;

$querySetting =
mysqli_query($conn,

"SELECT *

FROM setting_app

LIMIT 1");

$setting =
mysqli_fetch_assoc(
$querySetting
);

$semester =
$setting['semester_aktif'];

$jenjangAktif =
$setting['jenjang_aktif'];

$querySetting = mysqli_query($conn,"
SELECT * FROM setting_app LIMIT 1
");

$setting = mysqli_fetch_assoc($querySetting);

$modeMunaqosah = $setting['mode_munaqosah'];

$activeTab =
$_POST['active_tab']
?? 'akhlaq';

$queryGenerus =
mysqli_query($conn,

"SELECT *

FROM generus

WHERE id='$id'");


$generus =
mysqli_fetch_assoc(
$queryGenerus
);

if(!$generus){

    die(
    "Data generus tidak ditemukan.
    ID = ".$id
    );
}

if($role == 'pjp_kelompok'){

    if($generus['kelompok'] !=
    $_SESSION['kelompok']){

        die("Tidak punya akses");
    }
}

if($role == 'pjp_desa'){

    if($generus['desa'] !=
    $_SESSION['desa']){

        die("Tidak punya akses");
    }
}

if(isset($_POST['simpan'])){

    $activeTab =
    $_POST['active_tab']
    ?? 'akhlaq';

    /*
    =========================
    SAVE NILAI MATERI
    =========================
    */

    if(isset($_POST['nilai'])){

        foreach(
        $_POST['nilai']
        as $materiId => $nilai){

if(
$nilai === ''
||
$nilai === null
){

    if($role == 'master'){

        mysqli_query($conn,

        "DELETE FROM nilai_munaqosah

        WHERE

        nis='".$generus['nis']."'

        AND semester='$semester'

        AND materi_id='$materiId'
        ");
    }

    continue;
}
            $materiQuery =
            mysqli_query($conn,

            "SELECT *

            FROM materi_munaqosah

            WHERE id='$materiId'");

            $materi =
            mysqli_fetch_assoc(
            $materiQuery
            );
            
$kategoriSave =
mysqli_real_escape_string(
$conn,
$materi['kategori']
);

$babSave =
mysqli_real_escape_string(
$conn,
$materi['bab']
);

$materiSave =
mysqli_real_escape_string(
$conn,
$materi['materi']
);
            
            $cek =
            mysqli_query($conn,

            "SELECT *

            FROM nilai_munaqosah

            WHERE

            nis='".$generus['nis']."'

            AND semester='$semester'

            AND materi_id='$materiId'
            ");

            if(mysqli_num_rows($cek)>0){

                if($role == 'master'){

                    mysqli_query($conn,

                    "UPDATE nilai_munaqosah

                    SET nilai='$nilai'

                    WHERE

                    nis='".$generus['nis']."'

                    AND semester='$semester'

                    AND materi_id='$materiId'
                    ");
                }

            } else {

                mysqli_query($conn,

                "INSERT INTO nilai_munaqosah(

                id_generus,
                nis,
                semester,
                kelas,
                kategori,
                bab,
                materi,
                nilai,
                penilai,
                desa,
                kelompok,
                materi_id

                ) VALUES (

                '".$generus['id']."',

                '".$generus['nis']."',

                '$semester',

                '".$generus['kelas_kbm']."',

                '$kategoriSave',

                '$babSave',

                '$materiSave',

                '$nilai',

                '".$_SESSION['username']."',

                '".$generus['desa']."',

                '".$generus['kelompok']."',

                '$materiId'

                )");
            }
        }
    }

    /*
    =========================
    SAVE KEPRIBADIAN
    =========================
    */

    if(isset($_POST['kepribadian'])){

        foreach(
        $_POST['kepribadian']
        as $item => $nilaiKep){
            
            $item =
            trim($item);

            $nilaiKep =
            trim($nilaiKep);
            
$catatan =
mysqli_real_escape_string(
$conn,
$_POST['catatan_kepribadian'] ?? ''
);

if(
    $nilaiKep === ''
    ||
    $nilaiKep === null
){

    // Jika nilai dan catatan sama-sama kosong
    if(trim($catatan) == ''){

        if($role == 'master'){

            mysqli_query($conn,"
            DELETE FROM detail_kepribadian
            WHERE
            nis='".$generus['nis']."'
            AND semester='$semester'
            AND item_penilaian='$item'
            ");

        }

        continue;
    }

    // Kalau ada catatan tapi nilai kosong,
    // tetap lanjut INSERT.
}
            $item =
            mysqli_real_escape_string(
            $conn,
            $item
            );

            $nilaiKep =
            mysqli_real_escape_string(
            $conn,
            $nilaiKep
            );

            $catatan =
            mysqli_real_escape_string(
            $conn,

            $_POST[
            'catatan_kepribadian'
            ] ?? ''
            );

            $cek =
            mysqli_query($conn,

            "SELECT *

            FROM detail_kepribadian

            WHERE

            nis='".$generus['nis']."'

            AND semester='$semester'

            AND item_penilaian='$item'
            ");

if(mysqli_num_rows($cek)>0){

    $dataLama = mysqli_fetch_assoc($cek);

    // MASTER boleh mengubah semuanya
    if($role == 'master'){

        mysqli_query($conn,"
        UPDATE detail_kepribadian
        SET
        nilai='$nilaiKep',
        catatan='$catatan'
        WHERE
        nis='".$generus['nis']."'
        AND semester='$semester'
        AND item_penilaian='$item'
        ");

    }

    // PJP hanya boleh mengisi catatan yang masih kosong
    else{

        if(trim($dataLama['catatan']) == ''){

            mysqli_query($conn,"
            UPDATE detail_kepribadian
            SET
            catatan='$catatan'
            WHERE
            nis='".$generus['nis']."'
            AND semester='$semester'
            AND item_penilaian='$item'
            ");

        }

    }

}else{

    mysqli_query($conn,"
    INSERT INTO detail_kepribadian(

    nis,
    semester,
    item_penilaian,
    nilai,
    catatan,
    penilai

    ) VALUES (

    '".$generus['nis']."',

    '$semester',

    '$item',

    '$nilaiKep',

    '$catatan',

    '".$_SESSION['username']."'

    )");

}
        }
    }

    echo '

    <div class="alert alert-success">

    Nilai berhasil disimpan

    </div>

    ';
}

include 'templates/header.php';

?>

<div class="container-fluid mt-4">

<div class="card shadow">

<div class="card-body">

<h3>

Input Nilai Munaqosah

</h3>

<hr>
<div class="mb-3">

<b>NIS:</b>
<?php echo $generus['nis']; ?>

<br>

<b>Nama:</b>
<?php echo $generus['nama_santri']; ?>

<br>

<b>Kelas KBM:</b>
<?php echo $generus['kelas_kbm']; ?>

<div class="alert alert-info">

Semester Aktif:
<b>

<?php
echo $semester;
?>

</b>

</div>
</div>
</div>

</div>



<form method="POST">

<input
type="hidden"
name="active_tab"
id="active_tab"

value="<?php
echo $activeTab
?? 'akhlaq';
?>">

<?php
if($role == 'master'){
?>
<div class="mb-3">

<label>
Semester
</label>

<select
name="semester"

onchange="
this.form.submit()
"
class="form-control"
required>

<option value="">
Pilih Semester
</option>

<?php
for($i=1;$i<=2;$i++){
?>

<option
value="<?php echo $i; ?>"

<?php
if($semester==$i)
echo 'selected';
?>>

Semester
<?php echo $i; ?>

</option>

<?php } ?>

</select>

</div>

<?php } ?>
<ul class="nav nav-tabs">

<li class="nav-item">

<button
class="nav-link active"

data-bs-toggle="tab"

data-bs-target="#akhlaq"

type="button">

Akhlaqul Karimah

</button>

</li>

<li class="nav-item">

<button
class="nav-link"

data-bs-toggle="tab"

data-bs-target="#fiqih"

type="button">

Alim - Faqih

</button>

</li>

<li class="nav-item">

<button
class="nav-link"

data-bs-toggle="tab"

data-bs-target="#mandiri"

type="button">

Kemandirian

</button>

</li>

<li class="nav-item">

<button
class="nav-link"

data-bs-toggle="tab"

data-bs-target="#kepribadian"

type="button">

Kepribadian

</button>

</li>

</ul>

<div class="tab-content mt-4">

<?php

$kategoriList = [

'AKHLAQ' =>
'akhlaq',

'ALIM & FAQIH' =>
'fiqih',

'KEMANDIRIAN' =>
'mandiri'

];

$first = true;

foreach($kategoriList
as $kategori => $tab){

?>

<div

class="
tab-pane fade
<?php
if($first){
echo 'show active';
}
?>

"

id="<?php echo $tab; ?>">

<?php

$queryMateri =
mysqli_query($conn,

"SELECT *

FROM materi_munaqosah

WHERE
TRIM(kategori)=TRIM('$kategori')

AND
TRIM(kelas)=TRIM(
'".$generus['kelas_kbm']."'
)

AND
TRIM(semester)=TRIM(
'$semester'
)

ORDER BY id");

?>

<table
class="table table-bordered">

<tr class="table-dark">

<th>Bab</th>
<th>Materi</th>
<th>Nilai</th>

</tr>

<?php

if(mysqli_num_rows($queryMateri)==0){
?>

<tr>

<td colspan="3"
class="text-center text-danger">

Materi belum tersedia
untuk kelas
<?php echo $generus['kelas_kbm']; ?>

semester
<?php echo $semester; ?>

</td>

</tr>

<?php
}

while($materi =
mysqli_fetch_assoc(
$queryMateri
)){

?>

<tr>

<td>
<?php echo $materi['bab']; ?>
</td>

<td>
<?php echo $materi['materi']; ?>
</td>

<td width="150">

<?php

$queryNilaiLama =
mysqli_query($conn,

"SELECT *

FROM nilai_munaqosah

WHERE

nis='".$generus['nis']."'

AND semester='$semester'

AND materi_id='
".$materi['id']."'

LIMIT 1");

$nilaiLama =
mysqli_fetch_assoc(
$queryNilaiLama
);

$sudahAda = false;

if(
isset($nilaiLama['nilai'])
&&
$nilaiLama['nilai'] !== ''
&&
$nilaiLama['nilai'] !== null
){

$sudahAda = true;

}
?>

<input
type="number"

name="nilai[
<?php echo $materi['id']; ?>
]"

class="form-control"

min="0"
max="100"
step="1"

value="<?php

if(
isset($nilaiLama['nilai'])
&&
$nilaiLama['nilai'] != 0
){

    echo $nilaiLama['nilai'];
}
?>"

<?php

if(
$sudahAda
&&
$role != 'master'
){

echo 'readonly';

}
?>

>

</td>

</tr>

<?php } ?>

</table>

</div>

<?php
$first = false;
}
?>

<div
class="tab-pane fade"
id="kepribadian">

<table
class="table table-bordered">

<tr class="table-dark">

<th>Penilaian</th>
<th>Nilai</th>

</tr>

<?php

$itemKepribadian = [

'Sikap ketika mengaji',

'Sikap terhadap guru',

'Sikap dengan teman',

'Sikap ketika bertamu dengan orang lain',

'Kehadiran mengikuti pengajian',

'Hadir tepat waktu',

'Pengerjaan tugas',

'Pakaian menutup aurot',

'Merapikan sarana mengaji',

'Tidak mencorat coret sarana mengaji'

];

foreach($itemKepribadian as $item){

$queryKep =
mysqli_query($conn,

"SELECT nilai

FROM detail_kepribadian

WHERE

nis='".$generus['nis']."'

AND semester='$semester'

AND item_penilaian='$item'

LIMIT 1");

$dataKep =
mysqli_fetch_assoc(
$queryKep
);

$nilaiKepribadian =
$dataKep['nilai']
?? '';

$sudahKep = false;

if($nilaiKepribadian != ''){

    $sudahKep = true;
}

?>

<tr>

<td>

<?php echo $item; ?>

</td>

<td width="200">

<input
type="number"

name="kepribadian[
<?php echo $item; ?>
]"

class="form-control"

min="0"
max="100"

value="<?php

if(
$nilaiKepribadian != 0
){

    echo $nilaiKepribadian;
}
?>"

<?php

if(
$sudahKep
&&
$role != 'master'
){

echo 'readonly';

}
?>
>

</td>

</tr>

<?php } ?>

<tr>

<td>

Catatan

</td>

<td>

<?php

$queryCatatan =
mysqli_query($conn,

"SELECT *

FROM detail_kepribadian

WHERE

nis='".$generus['nis']."'

AND semester='$semester'

LIMIT 1");

$dataCatatan =
mysqli_fetch_assoc(
$queryCatatan
);
?>

<textarea
name="catatan_kepribadian"
class="form-control"><?php

echo
$dataCatatan['catatan']
?? '';

?></textarea>

</td>

</tr>

</table>

</div>

</div>

<br>

<?php

$queryTotalMateri =
mysqli_query($conn,

"SELECT COUNT(DISTINCT id)
as total

FROM materi_munaqosah

WHERE

TRIM(semester)=TRIM('$semester')

AND

TRIM(kelas)=TRIM(
'".$generus['kelas_kbm']."'
)
");

$totalMateri =
mysqli_fetch_assoc(
$queryTotalMateri
)['total'];

$queryIsiMateri =
mysqli_query($conn,

"SELECT COUNT(DISTINCT materi_id)
as total

FROM nilai_munaqosah

WHERE

nis='".$generus['nis']."'

AND

TRIM(semester)=TRIM('$semester')

AND nilai IS NOT NULL

AND nilai != ''

AND nilai != '0'
");

$totalIsiMateri =
mysqli_fetch_assoc(
$queryIsiMateri
)['total'];

$queryIsiKepribadian =
mysqli_query($conn,

"SELECT COUNT(DISTINCT item_penilaian)
as total

FROM detail_kepribadian

WHERE

nis='".$generus['nis']."'

AND semester='$semester'

AND nilai IS NOT NULL

AND nilai != ''

AND nilai != '0'
");

$totalIsiKepribadian =
mysqli_fetch_assoc(
$queryIsiKepribadian
)['total'];

$totalSemua =
$totalMateri;

$totalIsiSemua =
$totalIsiMateri
+
$totalIsiKepribadian;

$progress = 0;

if($totalSemua > 0){

$progress =
round(


($totalIsiSemua /
$totalSemua)
* 100,

2

);

echo '

<div class="alert alert-warning">

Total Materi:
'.$totalMateri.'

<br>

Total Isi:
'.$totalIsiSemua.'

<br>

</div>

';

}
?>


<div class="mb-4">

<label>

Progress Pengisian Nilai

</label>

<div class="progress">

<div

class="progress-bar bg-success"

style="
width:
<?php echo $progress; ?>%;
">

<?php
echo $progress;
?>%

</div>

</div>

</div>

<?php if($modeMunaqosah == 'aktif'){ ?>
<button type="submit" name="simpan" class="btn btn-primary">
Simpan Nilai
</button>
<?php } else { ?>
<div class="alert alert-warning">
Mode munaqosah sedang NONAKTIF (hanya lihat data)
</div>
<?php } ?>

<a href=
"penilaian_kelompok.php?kelompok=
<?php echo urlencode(
$generus['kelompok']
); ?>"

class="btn btn-secondary">

Kembali

</a>

</form>

</div>

</div>

</div>

<script>

document
.querySelectorAll(
'button[data-bs-toggle="tab"]'
)

.forEach(tab => {

    tab.addEventListener(
    'shown.bs.tab',

    function(event){

        let target =
        event.target
        .getAttribute(
        'data-bs-target'
        );

        target =
        target.replace('#','');

        document
        .getElementById(
        'active_tab'
        )
        .value = target;
    });
});

</script>

<?php
include 'templates/footer.php';
?>