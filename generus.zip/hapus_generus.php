<?php
session_start();

if($_SESSION['role'] != 'master'){

    die("Tidak punya akses");

}

if(!isset($_SESSION['login'])){

    die("Harus login");

}

include 'config.php';

$id = $_GET['id'];

$query = mysqli_query($conn,
"SELECT * FROM generus WHERE id='$id'");

$data = mysqli_fetch_assoc($query);

$role = $_SESSION['role'];

if($role == 'pjp_desa'){

    if($data['desa']
    != $_SESSION['desa']){

        die("Tidak punya akses");
    }
}

if($role == 'pjp_kelompok'){

    if($data['kelompok']
    != $_SESSION['kelompok']){

        die("Tidak punya akses");
    }
}

mysqli_query($conn,
"DELETE FROM generus WHERE id='$id'");

header("Location: data_generus.php");
?>