<?php
session_start();

include 'config.php';

if($_SESSION['role'] != 'master'){

    die("Tidak punya akses");
}

/*
PASTIKAN:
tidak ada spasi
di atas tag <?php
*/

header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=data_generus.csv");

$output = fopen("php://output", "w");

fputcsv($output, array(

    'Nomor',
    'Desa',
    'Kelompok',
    'Madrasah',
    'NIS',
    'Nama Bapak',
    'Nama Ibu',
    'Pekerjaan Bapak',
    'Pekerjaan Ibu',
    'Nomor WA',
    'Nama Santri',
    'Jenis Kelamin',
    'Kota Lahir',
    'Tanggal Lahir',
    'Anak Ke',
    'Dari Saudara',
    'Kelas Sekolah',
    'Kelas KBM',
    'Jenjang Generus',
    'Status Generus',
    'Keterangan'

));

$query = mysqli_query($conn,
"SELECT * FROM generus
ORDER BY id DESC");

while($data = mysqli_fetch_assoc($query)){

    fputcsv($output, array(

        $data['nomor'],
        $data['desa'],
        $data['kelompok'],
        $data['madrasah'],
        $data['nis'],
        $data['nama_bapak'],
        $data['nama_ibu'],
        $data['pekerjaan_bapak'],
        $data['pekerjaan_ibu'],
        $data['nomor_wa'],
        $data['nama_santri'],
        $data['jenis_kelamin'],
        $data['kota_lahir'],
        $data['tanggal_lahir'],
        $data['anak_ke'],
        $data['dari_saudara'],
        $data['kelas_sekolah'],
        $data['kelas_kbm'],
        $data['jenjang_generus'],
        $data['status_generus'],
        $data['keterangan']

    ));
}

fclose($output);
exit;
?>