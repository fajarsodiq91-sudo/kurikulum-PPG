<?php

session_start();

include 'config.php';

$role = $_SESSION['role'] ?? 'viewer';

if($role != 'master'){
    die("Tidak punya akses");
}

$querySetting =
mysqli_query($conn,

"SELECT *
FROM setting_app
LIMIT 1");

$setting =
mysqli_fetch_assoc($querySetting);

$semester =
$setting['semester_aktif'];

$jenjangAktif =
$setting['jenjang_aktif'];

$jenjangList =
array_filter(
array_map(
'trim',
explode(',',$jenjangAktif)
)
);

$jenjangSql = '';

if(!empty($jenjangList)){

    $jenjangSql =
    "'" .
    implode(
    "','",
    $jenjangList
    ) .
    "'";
}

header(
"Content-Type: text/csv"
);

header(
"Content-Disposition: attachment; filename=resume_munaqosah_semester_".$semester.".csv"
);

$output =
fopen("php://output","w");

fputcsv($output,[

'NIS',
'Nama',
'Semester',
'Kelas',
'3 Sukses',
'BAB',
'Materi',
'Nilai',
'Catatan'

]);

$query =
mysqli_query($conn,

"

SELECT

g.nis,
g.nama_santri,
g.kelas_kbm,

m.semester,
m.kategori,
m.bab,
m.materi,

n.nilai,

k.catatan

FROM generus g

INNER JOIN materi_munaqosah m

ON

TRIM(m.kelas)=TRIM(g.kelas_kbm)

AND

TRIM(m.semester)=TRIM('$semester')

LEFT JOIN nilai_munaqosah n

ON

n.nis=g.nis

AND

n.materi_id=m.id

AND

n.semester='$semester'

LEFT JOIN (

    SELECT
        nis,
        semester,
        MAX(catatan) AS catatan

    FROM detail_kepribadian

    GROUP BY
        nis,
        semester

) k

ON

k.nis = g.nis

AND

k.semester = '$semester'

WHERE

g.jenjang_generus
IN ($jenjangSql)

ORDER BY

g.kelas_kbm,
g.nama_santri,
m.id

");

while(
$row =
mysqli_fetch_assoc($query)
){

    fputcsv($output,[

    $row['nis'],
    $row['nama_santri'],
    $row['semester'],
    $row['kelas_kbm'],
    $row['kategori'],
    $row['bab'],
    $row['materi'],
    $row['nilai'],
    $row['catatan']

    ]);
}

fclose($output);

exit;
?>