<?php

session_start();

include 'config.php';

$role =
$_SESSION['role'] ?? 'viewer';

if(
isset($_POST['ganti_semester'])
&&
$role == 'master'
){

    $semesterBaru =
    $_POST['semester'];
    
$jenjangAktif = '';

if(
isset($_POST['jenjang'])
){

    $jenjangAktif =
    implode(
    ',',
    $_POST['jenjang']
    );
}

mysqli_query($conn,

"UPDATE setting_app

SET

semester_aktif=
'$semesterBaru',

jenjang_aktif=
'$jenjangAktif'

WHERE id=1");

    header(
    "Location:munaqosah.php"
    );

    exit;
}

if(isset($_POST['update_mode']) && $role == 'master'){

    $mode = $_POST['mode_munaqosah'];

    mysqli_query($conn,"
        UPDATE setting_app 
        SET mode_munaqosah='$mode'
        WHERE id=1
    ");

    header("Location: munaqosah.php");
    exit;
}

include 'templates/header.php';

$modeTampilan =
$_GET['mode'] ?? 'persentase';

$querySetting =
mysqli_query($conn,

"SELECT *

FROM setting_app

LIMIT 1");

$setting = mysqli_fetch_assoc($querySetting) ?? [];

$semester =
$setting['semester_aktif'];

$jenjangAktif =
$setting['jenjang_aktif'];


$jenjangSql = '';

if($jenjangAktif != ''){

    $arrJenjang =
    explode(
    ',',
    $jenjangAktif
    );

    $jenjangSql =
    "'" .
    implode(
    "','",
    $arrJenjang
    ) .
    "'";
}

$daftarJenjang =
explode(
',',
$jenjangAktif
);

$queryKelompok = mysqli_query($conn,

"SELECT
desa,
kelompok,

COUNT(*) as total_generus

FROM generus

GROUP BY desa, kelompok

ORDER BY desa, kelompok");

?>

<div class="container-fluid mt-4">

<div class="card shadow">

<div class="card-body">

<h3 class="mb-4">

Dashboard Munaqosah

</h3>

<?php if($role == 'master'){ ?>

<a href="resume_munaqosah.php" 
class="btn btn-info mb-3">

Resume Penilaian Munaqosah

</a>

<?php } ?>

<?php
if($role == 'master'){
?>

<a href="export_resume_munaqosah.php"
class="btn btn-success">

Export CSV

</a>

<?php } ?>

<div class="mb-3">

<a href="dashboard.php"
class="btn btn-secondary">

Kembali Dashboard

</a>

</div>

<?php
if($role == 'master'){
?>

<form method="POST"
class="mb-4">

<div class="row">

<div class="col-md-3">

<select
name="mode"
class="form-control">

<option value="persentase"

<?php
if($modeTampilan=='persentase')
echo 'selected';
?>>

Persentase Pengisian

</option>

<option value="rata">

<?php
if($modeTampilan=='rata')
echo 'selected';
?>>

Rata-Rata Nilai

</option>

<option value="total">

<?php
if($modeTampilan=='total')
echo 'selected';
?>>

Total Nilai

</option>

</select>

</div>

<div class="col-md-3">

<select
name="semester"
class="form-control">

<option value="">
Semua Semester
</option>

<?php
for($s=1;$s<=2;$s++){
?>

<option
value="<?php echo $s; ?>"

<?php
if($semester==$s)
echo 'selected';
?>>

Semester
<?php echo $s; ?>

</option>

<?php } ?>

</select>

</div>

<div class="col-md-2">

<button
type="submit"

name="ganti_semester"

class="btn btn-primary">

Update Semester

</button>

</div>

</div>

<div class="col-md-4">

<label>
Jenjang Aktif
</label>

<div class="form-check">

<input
class="form-check-input"
type="checkbox"
name="jenjang[]"
value="PAUD"

<?php

if(
in_array(
'PAUD',
explode(
',',
$setting['jenjang_aktif']
)
)
){
    echo 'checked';
}

?>

>

<label class="form-check-label">

PAUD

</label>

</div>

<div class="form-check">

<input
class="form-check-input"
type="checkbox"
name="jenjang[]"
value="Caberawit"

<?php

if(
in_array(
'Caberawit',
explode(
',',
$setting['jenjang_aktif']
)
)
){
    echo 'checked';
}

?>

>

<label class="form-check-label">

Caberawit

</label>

</div>

<div class="form-check">

<input
class="form-check-input"
type="checkbox"
name="jenjang[]"
value="Pra Remaja"

<?php

if(
in_array(
'Pra Remaja',
explode(
',',
$setting['jenjang_aktif']
)
)
){
    echo 'checked';
}

?>

>

<label class="form-check-label">

Pra Remaja

</label>

</div>

<div class="form-check">

<input
class="form-check-input"
type="checkbox"
name="jenjang[]"
value="Remaja"

<?php

if(
in_array(
'Remaja',
explode(
',',
$setting['jenjang_aktif']
)
)
){
    echo 'checked';
}

?>

>

<label class="form-check-label">

Remaja

</label>

</div>

<div class="form-check">

<input
class="form-check-input"
type="checkbox"
name="jenjang[]"
value="Pra Nikah"

<?php
if(
strpos(
$setting['jenjang_aktif'],
'Pra Nikah'
)!==false
){
echo 'checked';
}
?>

>

<label class="form-check-label">

Pra Nikah

</label>

</div>

</div>

</form>

<?php } ?>

<?php if($role == 'master'){ ?>
<form method="POST">

<select name="mode_munaqosah" class="form-control">

<option value="aktif"
<?php if($setting['mode_munaqosah']=='aktif') echo 'selected'; ?>>
Aktif (Bisa Input Nilai)
</option>

<option value="nonaktif"
<?php if($setting['mode_munaqosah']=='nonaktif') echo 'selected'; ?>>
Non Aktif (Read Only)
</option>

</select>

<button type="submit" name="update_mode" class="btn btn-primary mt-2">
Simpan Mode
</button>

</form>
<?php } ?>

<div class="table-responsive">

<table
class="table table-bordered
table-striped table-hover">

<tr class="table-dark">

<th>No</th>
<th>Desa</th>
<th>Kelompok</th>
<th>Total Generus</th>

<?php
if($modeTampilan=='persentase'){
?>

<th>Progress Penilaian</th>

<?php } ?>

<?php
if($modeTampilan=='rata'){
?>

<th>Rata-Rata Nilai</th>

<?php } ?>

<?php
if($modeTampilan=='total'){
?>

<th>Total Nilai</th>

<?php } ?>

<th>Aksi</th>

</tr>

<?php

$no = 1;
$grandTotalGenerus = 0;
$grandSudah = 0;
$currentDesa = '';
$subtotalGenerus = 0;
$subtotalNilai = 0;
$grandNilai = 0;
$subtotalMateri = 0;
$subtotalIsi = 0;

$grandMateri = 0;
$grandIsi = 0;
$subtotalSudah = 0;

while($kelompok =
mysqli_fetch_assoc(
$queryKelompok
)){

    $desa =
    $kelompok['desa'];

    $namaKelompok =
    $kelompok['kelompok'];

$queryTotalGenerus =
mysqli_query($conn,

"SELECT COUNT(*) as total

FROM generus

WHERE kelompok='$namaKelompok'

AND jenjang_generus
IN ($jenjangSql)

AND status_generus='Masih Generus'"
);

$totalGenerus =
mysqli_fetch_assoc(
$queryTotalGenerus
)['total'];

$whereSemester = "";

if(!empty($semester)){

    $whereSemester =
    "AND semester='$semester'";
}


$queryGenerusKelompok =
mysqli_query($conn,

"SELECT nis

FROM generus

WHERE kelompok='$namaKelompok'

AND jenjang_generus
IN ($jenjangSql)

AND status_generus='Masih Generus'");

$totalMateriKelompok = 0;
$totalIsiKelompok = 0;

while($g =
mysqli_fetch_assoc(
$queryGenerusKelompok
)){

    $nis = $g['nis'];

    $queryDataGenerus =
    mysqli_query($conn,

    "SELECT *

    FROM generus

    WHERE nis='$nis'

    LIMIT 1");

    $dataGenerus =
    mysqli_fetch_assoc(
    $queryDataGenerus
    );

    $kelasKBM =
    $dataGenerus['kelas_kbm'];

    /*
    =========================
    TOTAL MATERI
    =========================
    */

    $queryTotalMateri =
    mysqli_query($conn,

    "SELECT COUNT(DISTINCT id)
    as total

    FROM materi_munaqosah

    WHERE

    TRIM(semester)=TRIM('$semester')

    AND

    TRIM(kelas)=TRIM('$kelasKBM')
    ");

    $totalMateri =
    mysqli_fetch_assoc(
    $queryTotalMateri
    )['total'];

    /*
    =========================
    YANG SUDAH DIISI
    =========================
    */

    $queryIsiMateri =
    mysqli_query($conn,

    "SELECT COUNT(DISTINCT materi_id)
    as total

    FROM nilai_munaqosah

    WHERE

    nis='$nis'

    AND semester='$semester'
    ");

    $totalIsiMateri =
    mysqli_fetch_assoc(
    $queryIsiMateri
    )['total'];

    /*
    =========================
    PROGRESS SANTRI
    =========================
    */
    
$totalIsiSemua =
$totalIsiMateri;

$totalMateriKelompok +=
$totalMateri;

$queryKepribadian =
mysqli_query($conn,
"SELECT COUNT(DISTINCT item_penilaian) as total
FROM detail_kepribadian
WHERE nis='$nis'
AND semester='$semester'");

$totalKepribadian =
mysqli_fetch_assoc($queryKepribadian)['total'];

$totalIsiKelompok += ($totalIsiMateri + $totalKepribadian);
}

if(
$currentDesa != ''
&&
$currentDesa != $desa
){

$subtotalPersen = 0;

if($subtotalMateri > 0){

    $subtotalPersen =
    round(

    ($subtotalIsi /
    $subtotalMateri)
    * 100,

    2

    );
}

?>

<tr
style="
background:#ffe8a1;
font-weight:bold;
">

<td colspan="3">

Subtotal
<?php echo $currentDesa; ?>

</td>

<td>

<?php
echo $subtotalGenerus;
?>

</td>

<?php
if($modeTampilan=='persentase'){
?>

<td>

<?php
echo $subtotalPersen;
?>%

</td>

<?php } ?>

<?php
if($modeTampilan=='rata'){
?>

<td>

<?php
echo round(
$subtotalNilai /
max($subtotalSudah,1),
2
);
?>

</td>

<?php } ?>

<?php
if($modeTampilan=='total'){
?>

<td>

<?php
echo $subtotalNilai;
?>

</td>

<?php } ?>

<td></td>

</tr>

<?php

$subtotalGenerus = 0;

$subtotalMateri = 0;

$subtotalIsi = 0;

}

$subtotalGenerus +=
$totalGenerus;

$grandTotalGenerus +=
$totalGenerus;

$currentDesa =
$desa;

$subtotalNilai +=
$totalNilai;

$grandNilai +=
$totalNilai;

$persentase = 0;

$persentase = 0;

if($totalMateriKelompok > 0){

    $persentase =
    round(

    ($totalIsiKelompok /
    $totalMateriKelompok)
    * 100,

    2

    );
}

$subtotalMateri +=
$totalMateriKelompok;

$subtotalIsi +=
$totalIsiKelompok;

$grandMateri +=
$totalMateriKelompok;

$grandIsi +=
$totalIsiKelompok;

?>

<tr>

<td>
<?php echo $no++; ?>
</td>

<td>
<?php echo $desa; ?>
</td>

<td>
<?php echo $namaKelompok; ?>
</td>

<td>
<?php echo $totalGenerus; ?>
</td>

<?php
if($modeTampilan=='persentase'){
?>

<td>

<div
class="progress">

<div
class="progress-bar bg-success"

style="
width:
<?php
echo $persentase;
?>%;
">

<?php
echo $persentase;
?>%

</div>

</div>

</td>

<?php } ?>

<?php
if($modeTampilan=='rata'){
?>

<td>

<b>

<?php
echo $rata;
?>

</b>

</td>

<?php } ?>

<?php
if($modeTampilan=='total'){
?>

<td>

<b>

<?php
echo $totalNilai;
?>

</b>

</td>

<?php } ?>

<td>

<a href=
"penilaian_kelompok.php?kelompok=
<?php echo urlencode(
$namaKelompok
); ?>"

class="btn btn-primary btn-sm">

Input Nilai

</a>

</td>

</tr>

<?php } ?>

<?php

$subtotalPersen = 0;

if($subtotalMateri > 0){

    $subtotalPersen =
    round(

    ($subtotalIsi /
    $subtotalMateri)
    * 100,

    2

    );
}

?>

<tr
style="
background:#ffe8a1;
font-weight:bold;
">

<td colspan="3">

Subtotal
<?php echo $currentDesa; ?>

</td>

<td>

<?php
echo $subtotalGenerus;
?>

</td>

<?php
if($modeTampilan=='persentase'){
?>

<td>

<?php
echo $subtotalPersen;
?>%

</td>

<?php } ?>

<?php
if($modeTampilan=='rata'){
?>

<td>

<?php

$rataSubtotal = 0;

if($subtotalSudah > 0){

$rataSubtotal =
round(
$subtotalNilai /
$subtotalSudah,
2
);

}

echo $rataSubtotal;

?>

</td>

<?php } ?>

<?php
if($modeTampilan=='total'){
?>

<td>

<?php
echo $subtotalNilai;
?>

</td>

<?php } ?>

<td></td>

</tr>

<?php

$grandPersen = 0;

if($grandMateri > 0){

    $grandPersen =
    round(

    ($grandIsi /
    $grandMateri)
    * 100,

    2

    );
}

?>

<tr class="table-dark">

<td colspan="3">

<b>
GRAND TOTAL
</b>

</td>

<td>

<b>
<?php
echo $grandTotalGenerus;
?>
</b>

</td>

<?php
if($modeTampilan=='persentase'){
?>

<td>

<b>
<?php echo $grandPersen; ?>%
</b>

</td>

<?php } ?>

<?php
if($modeTampilan=='rata'){
?>

<td>

<b>

<?php

$rataGrand = 0;

if($grandSudah > 0){

$rataGrand =
round(
$grandNilai /
$grandSudah,
2
);

}

echo $rataGrand;

?>

</b>

</td>

<?php } ?>

<?php
if($modeTampilan=='total'){
?>

<td>

<b>
<?php echo $grandNilai; ?>
</b>

</td>

<?php } ?>

<td></td>

</tr>

</table>

</div>

</div>

</div>

</div>

<?php
include 'templates/footer.php';
?>