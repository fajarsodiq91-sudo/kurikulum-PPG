<?php
session_start();
include 'config.php';

if(isset($_POST['login'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Catatan keamanan: Disarankan menggunakan Prepared Statements di masa depan untuk menghindari SQL Injection
    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' AND password='$password' AND status_approval='approved'");
    $data = mysqli_fetch_assoc($query);

    if($data){
        $_SESSION['login'] = true;
        $_SESSION['role'] = $data['role'];
        $_SESSION['id'] = $data['id'];
        $_SESSION['desa'] = $data['desa'];
        $_SESSION['kelompok'] = $data['kelompok'];
        header("Location: dashboard.php");
        exit(); // Bagus untuk menghentikan eksekusi script setelah redirect
    } else {
        $error = "Login gagal";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container d-flex align-items-center justify-content-center min-vh-100">
    <div class="row w-100 justify-content-center">
        <div class="col-12">
            
            <div class="card shadow">
                <div class="card-body">
                    <h3 class="text-center mb-4">Login Generus</h3>

                    <?php if(isset($error)){ ?>
                        <div class="alert alert-danger">
                            <?php echo $error; ?>
                        </div>
                    <?php } ?>

                    <div class="alert alert-info" style="font-size: 0.9rem;">
                        <b>Informasi Login:</b><br><br>
                        Silahkan klik tombol register di bawah, agar bisa update database dan input nilai munaqosah.<br><br>
                        1 login untuk Tim PJP Desa<br>
                        1 login untuk Tim PJP Kelompok<br><br>
                        Sementara ini, mohon gunakan login tersebut untuk berbarengan, untuk memudahkan kami dalam mengidentifikasi siapa saja yang menggunakan aplikasi ini dan agar tidak disalahgunakan<br><br>


                    </div>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>

                        <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
                        
                        <a href="dashboard.php" class="btn btn-secondary w-100 mt-2">Masuk Sebagai Viewer</a>
                    </form>

                    <hr>

                    <a href="register.php" class="btn btn-success w-100">Register</a>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>