<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

$role =
$_SESSION['role'] ?? 'viewer';
echo $role;
include 'config.php';

if(isset($_POST['hapus_massal'])){

    if($role != 'master'){

        die("Tidak punya akses");
    }

    if(isset($_POST['pilih'])){

        $pilih =
        $_POST['pilih'];

        foreach($pilih as $id){

            mysqli_query($conn,

            "DELETE FROM generus
            WHERE id='$id'");
        }

        echo '

        <div class="alert alert-success">

        Data berhasil dihapus

        </div>

        <meta http-equiv="refresh"
        content="1">

';
    }
}

$role = $_SESSION['role'] ?? 'viewer';

$desaSession = $_SESSION['desa'] ?? '';

$kelompokSession = $_SESSION['kelompok'] ?? '';

$cari = $_GET['cari'] ?? '';

$filterNis = $_GET['nis'] ?? '';

$filterJenisKelamin = $_GET['jenis_kelamin'] ?? '';

$filterDesa = $_GET['desa'] ?? '';

$filterKelompok = $_GET['kelompok'] ?? '';

$filterKelasSekolah = $_GET['kelas_sekolah'] ?? '';

$filterKelasKbm = $_GET['kelas_kbm'] ?? '';

$filterJenjangGenerus = $_GET['jenjang_generus'] ?? '';

$filterStatus = $_GET['status'] ?? '';

$sql = "SELECT * FROM generus WHERE 1=1";

if($role == 'pjp_desa'){

    $sql .= "
    AND desa='$desaSession'
    ";
}

if($role == 'pjp_kelompok'){

    $sql .= "
    AND kelompok='$kelompokSession'
    ";
}

if(!empty($cari)){

    $sql .= "
    AND nama_santri
    LIKE '%$cari%'
    ";
}

if(!empty($filterNis)){

    $sql .= "
    AND nis LIKE '%$filterNis%'
    ";
}

if(!empty($filterJenisKelamin)){

    $sql .= "
    AND jenis_kelamin LIKE '%$filterJenisKelamin%'
    ";
}

if(!empty($filterDesa)){

    $sql .= "
    AND desa='$filterDesa'
    ";
}

if(!empty($filterKelompok)){

    $sql .= "
    AND kelompok='$filterKelompok'
    ";
}

if(!empty($filterKelasSekolah)){

    $sql .= "
    AND kelas_sekolah='$filterKelasSekolah'
    ";
}

if(!empty($filterKelasKbm)){

    $sql .= "
    AND kelas_kbm='$filterKelasKbm'
    ";
}

if(!empty($filterStatus)){

    $sql .= "
    AND status_generus='$filterStatus'
    ";
}


if(!empty($filterJenjangGenerus)){

    $sql .= "
    AND jenjang_generus='$filterJenjangGenerus'
    ";
}

$sql .= "
ORDER BY id DESC
";

$query = mysqli_query($conn, $sql);
$totalData = mysqli_num_rows($query);
?>

<html>
<head>
    <title>Data Generus</title>

    <style>

    table{
        border-collapse: collapse;
        width: 100%;
    }

    table, th, td{
        border:1px solid black;
        padding:8px;
    }

    </style>

</head>
<body>

<link href=
"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<div class="container-fluid py-3">
    
<h2>Database Generus</h2>
<div class="card mb-4">

<div class="card-body">

<form method="GET">

<div class="row">

<div class="col-md-3 mb-2">

<input type="text"
name="cari"
class="form-control"
placeholder="Cari Nama Santri"

value="<?php echo $cari; ?>">


</div>

<div class="col-md-2 mb-2">

<input type="text"
name="nis"
class="form-control"
placeholder="Cari NIS"

value="<?php echo $filterNis; ?>">

</div>

<div class="col-md-2 mb-2">

<select name="jenis_kelamin" class="form-control">

<option value="">
Semua JK
</option>

<option value="Laki-Laki"
<?php
if($filterJenisKelamin == 'Laki-Laki'){
    echo 'selected';
}
?>>

Laki-Laki

</option>

<option value="Perempuan"
<?php
if($filterJenisKelamin == 'Perempuan'){
    echo 'selected';
}
?>>

Perempuan

</option>

</select>

</div>

<div class="col-md-2 mb-2">

<select
name="desa"
id="desa"
class="form-control"
onchange="updateKelompokFilter()">

<option value="">
Semua Desa
</option>

<option value="Adiarsa Timur"
<?php
if($filterDesa == 'Adiarsa Timur'){
    echo 'selected';
}
?>>

Adiarsa Timur

</option>

<option value="Klari"
<?php
if($filterDesa == 'Klari'){
    echo 'selected';
}
?>>

Klari

</option>

<option value="Lemah Mulya"
<?php
if($filterDesa == 'Lemah Mulya'){
    echo 'selected';
}
?>>

Lemah Mulya

</option>

<option value="Tunggak Jati"
<?php
if($filterDesa == 'Tunggak Jati'){
    echo 'selected';
}
?>>

Tunggak Jati

</option>

</select>

</div>

<div class="col-md-3 mb-2">

<select
name="kelompok"
id="kelompok"
class="form-control">

<option value="">
Semua Kelompok
</option>

</select>
</div>

<div class="col-md-2 mb-2">

<select
name="kelas_sekolah"
class="form-control">

<option value="">
Kelas Sekolah
</option>

<?php

$kelasSekolahList = [
'Pra PAUD',
'PAUD',
'TK',
'1',
'2',
'3',
'4',
'5',
'6',
'7',
'8',
'9',
'10',
'11',
'12',
'Mahasiswa',
'-'
];

foreach($kelasSekolahList as $k){

?>

<option
value="<?php echo $k; ?>"

<?php
if($filterKelasSekolah == $k){
    echo 'selected';
}
?>

>

<?php echo $k; ?>

</option>

<?php } ?>

</select>

</div>

<div class="col-md-2 mb-2">

<select
name="kelas_kbm"
class="form-control">

<option value="">
Kelas KBM
</option>

<?php

$kelasKbmList = [
'Pra PAUD',
'PAUD',
'1',
'2',
'3',
'4',
'5',
'6',
'7',
'8',
'9',
'10',
'11',
'12',
'Pra Nikah'
];

foreach($kelasKbmList as $k){

?>

<option
value="<?php echo $k; ?>"

<?php
if($filterKelasKbm == $k){
    echo 'selected';
}
?>

>

<?php echo $k; ?>

</option>

<?php } ?>

</select>

</div>

<div class="col-md-2 mb-2">

<select name="jenjang_generus" class="form-control">

<option value="">
Semua Jenjang
</option>

<option value="Pra PAUD"
<?php
if($filterJenjangGenerus == 'Pra PAUD'){
    echo 'selected';
}
?>>

Pra PAUD

</option>

<option value="PAUD"
<?php
if($filterJenjangGenerus == 'PAUD'){
    echo 'selected';
}
?>>

PAUD

</option>

<option value="Caberawit"
<?php
if($filterJenjangGenerus == 'Caberawit'){
    echo 'selected';
}
?>>

Caberawit

</option>

<option value="Pra Remaja"
<?php
if($filterJenjangGenerus == 'Pra Remaja'){
    echo 'selected';
}
?>>

Pra Remaja

</option>

<option value="Remaja"
<?php
if($filterJenjangGenerus == 'Remaja'){
    echo 'selected';
}
?>>

Remaja

</option>

<option value="Pra Nikah"
<?php
if($filterJenjangGenerus == 'Pra Nikah'){
    echo 'selected';
}
?>>

Pra Nikah

</option>

</select>

</div>

<div class="col-md-2 mb-2">

<select
name="status"
class="form-control">

<option value="">
Semua Status
</option>

<option value="Masih Generus"
<?php
if($filterStatus == 'Masih Generus'){
    echo 'selected';
}
?>>

Masih Generus

</option>

<option value="Pindah Sambung"
<?php
if($filterStatus == 'Pindah Sambung'){
    echo 'selected';
}
?>>

Pindah Sambung

</option>

<option value="Sudah Menikah"
<?php
if($filterStatus == 'Sudah Menikah'){
    echo 'selected';
}
?>>

Sudah Menikah

</option>

</select>

</div>

<div class="col-md-2 mb-2">

<button type="submit"
class="btn btn-primary w-100">

Search

</button>

</div>

</div>

</form>
<a href="dashboard.php"
class="btn btn-secondary">
Kembali Dashboard
</a>

</div>

</div>

<?php
if($role != 'viewer'){
?>

<a href="tambah_generus.php"
class="btn btn-primary mb-3">
Tambah Generus

</a>


<?php
if($role == 'master'){
?>

<a href="export_excel.php"
class="btn btn-success mb-3">

Export Excel

</a>

<?php } ?>

<?php
if($role == 'master'){
?>

<a href="import_excel.php"
class="btn btn-warning mb-3">

Import CSV

</a>

<?php } ?>

<?php } ?>

<div class="alert alert-info">

Total Data:
<b>

<?php echo $totalData; ?>

</b>

</div>

<div class="table-responsive"
style="max-height:75vh;">

<?php
if($role == 'master'){
?>
<form method="POST">

<div class="mb-3">

<button
type="submit"
name="hapus_massal"
class="btn btn-danger"

onclick="return confirm(
'Yakin hapus data terpilih?')">

Hapus Terpilih

</button>

</div>

<?php } ?>

<table
id="tabelGenerus"

class="table table-bordered
table-striped table-hover">

<table
id="tabelGenerus"

class="table table-bordered
table-striped table-hover">


<tr>

<?php
if($role == 'master'){
?>
<th>

<input
type="checkbox"
id="checkAll">

</th>
<?php } ?>

<th>NIS</th>
<th>Desa</th>
<th>Kelompok</th>
<th>Madrasah</th>
<th>Nama Bapak</th>
<th>Nama Ibu</th>
<th>Pekerjaan Bapak</th>
<th>Pekerjaan Ibu</th>
<th>Nomor WA</th>
<th>Nama Santri</th>
<th>Jenis Kelamin</th>
<th>Kota Lahir</th>
<th>Tanggal Lahir</th>
<th>Anak Ke</th>
<th>Dari Saudara</th>
<th>Kelas Sekolah</th>
<th>Kelas KBM</th>
<th>Jenjang Generus</th>
<th>Status Generus</th>
<th>Keterangan</th>

<?php
if($role != 'viewer'){?>

<th>Aksi</th>

<?php } ?>

</tr>

<?php
$no = 1;

while($data = mysqli_fetch_assoc($query)){
?>

<tr>

<?php
if($role == 'master'){
?>
<td>

<input
type="checkbox"
name="pilih[]"
value="<?php echo $data['id']; ?>">

</td>
<?php } ?>

<td><?php echo $data['nis']; ?></td>

<td><?php echo $data['desa']; ?></td>

<td><?php echo $data['kelompok']; ?></td>

<td><?php echo $data['madrasah']; ?></td>

<td><?php echo $data['nama_bapak']; ?></td>

<td><?php echo $data['nama_ibu']; ?></td>

<td><?php echo $data['pekerjaan_bapak']; ?></td>

<td><?php echo $data['pekerjaan_ibu']; ?></td>

<td><?php echo $data['nomor_wa']; ?></td>

<td><?php echo $data['nama_santri']; ?></td>

<td><?php echo $data['jenis_kelamin']; ?></td>

<td><?php echo $data['kota_lahir']; ?></td>

<td><?php echo $data['tanggal_lahir']; ?></td>

<td><?php echo $data['anak_ke']; ?></td>

<td><?php echo $data['dari_saudara']; ?></td>

<td><?php echo $data['kelas_sekolah']; ?></td>

<td><?php echo $data['kelas_kbm']; ?></td>

<td><?php echo $data['jenjang_generus']; ?> </td>

<td><?php echo $data['status_generus']; ?></td>

<td> <?php echo $data['keterangan']; ?> </td>

<?php

$bolehEdit = false;

if($role == 'master'){

    $bolehEdit = true;

}

elseif(
    $role == 'pjp_desa'
    &&
    $data['desa'] == $desaSession
){

    $bolehEdit = true;

}

elseif(
    $role == 'pjp_kelompok'
    &&
    $data['kelompok'] == $kelompokSession
){

    $bolehEdit = true;

}


if($role != 'viewer'){
?>

<td>

<?php
if($bolehEdit){
?>

<a href="edit_generus.php?id=<?php echo $data['id']; ?>"
class="btn btn-warning btn-sm">

Edit

</a>

<?php
if($role == 'master'){
?>

<a href=
"hapus_generus.php?id=<?php echo $data['id']; ?>"

class="btn btn-danger btn-sm"

onclick="return confirm(
'Yakin hapus data?')">

Hapus

</a>

<?php } ?>

<?php } ?>

</td>

<?php } ?>

</tr>

<?php } ?>

</table>

</table>

<?php
if($role == 'master'){
?>
</form>
<?php } ?>

</div>

<br><br>

<script>

function updateKelompokFilter(){

    let desa =
    document.getElementById("desa").value;

    let kelompok =
    document.getElementById("kelompok");

    let selectedKelompok =
    "<?php echo $filterKelompok; ?>";

    let data = {

        "Adiarsa Timur": [
            "Babakan Jati 1",
            "Babakan Jati 2",
            "Karawang Kota 1",
            "Karawang Kota 2",
            "Wadas",
            "Wirasaba"
        ],

        "Klari": [
            "Belendung",
            "Cibalongsari 1",
            "Cibalongsari 2",
            "Cirejag",
            "Kalimulya",
            "Pancawati"
        ],

        "Lemah Mulya": [
            "Anggadita",
            "CKM 1",
            "CKM 2",
            "HNH",
            "Tamiang 1",
            "Tamiang 2",
            "Karawang Megah",
            "Tipar"
        ],

        "Tunggak Jati": [
            "Kalang Surya",
            "Pakis",
            "Tanjung Baru Barat",
            "Tanjung Baru Timur",
            "Tunggak Jati"
        ]
    };

    kelompok.innerHTML =
    '<option value="">Semua Kelompok</option>';

    if(data[desa]){

        data[desa].forEach(function(item){

            let option =
            document.createElement("option");

            option.value = item;

            option.text = item;

            if(item == selectedKelompok){

                option.selected = true;
            }

            kelompok.appendChild(option);
        });
    }
}

updateKelompokFilter();

</script>

<script>

document
.getElementById('checkAll')
?.addEventListener(

'change',

function(){

    let checkboxes =
    document.querySelectorAll(

    'input[name="pilih[]"]'

    );

    checkboxes.forEach(

    function(checkbox){

        checkbox.checked =
        document
        .getElementById(
        'checkAll'
        ).checked;
    });
});

</script>
</body>
</html>