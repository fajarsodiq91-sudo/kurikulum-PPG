<?php
session_start();
include 'config.php';

$role = $_SESSION['role'] ?? 'viewer';

if($role != 'master'){
    die("Hanya master yang bisa akses");
}

$kelasAktif =
$_GET['kelas']
?? 'PAUD';

$querySetting = mysqli_query($conn,"
SELECT * FROM setting_app LIMIT 1
");

$setting = mysqli_fetch_assoc($querySetting);

$semester = $setting['semester_aktif'];
$jenjangAktif = $setting['jenjang_aktif'] ?? '';

$jenjangList = array_filter(array_map('trim', explode(',', $jenjangAktif)));

$jenjangSql = '';

if(!empty($jenjangList)){
    $jenjangSql = "'" . implode("','", $jenjangList) . "'";
}
?>

<?php
$query = mysqli_query($conn, "

SELECT

g.nis,
g.nama_santri,
g.desa,
g.kelompok,
g.kelas_kbm,

COUNT(DISTINCT m.id) as total_materi,

COUNT(DISTINCT n.materi_id) as total_terisi,

(
SELECT COUNT(DISTINCT item_penilaian)

FROM detail_kepribadian d

WHERE

d.nis = g.nis

AND d.semester='$semester'

) as total_kepribadian,

SUM(n.nilai) as total_nilai,

AVG(n.nilai) as rata_nilai

FROM generus g

LEFT JOIN materi_munaqosah m

ON

TRIM(m.kelas)=TRIM(g.kelas_kbm)

AND

TRIM(m.semester)=TRIM('$semester')

LEFT JOIN nilai_munaqosah n

ON

n.nis=g.nis

AND

n.materi_id=m.id

AND

n.semester='$semester'

WHERE

g.jenjang_generus IN ($jenjangSql)

AND g.kelas_kbm='$kelasAktif'

GROUP BY

g.nis

ORDER BY
SUM(n.nilai) DESC,
g.nama_santri

");
?>

<?php
include 'templates/header.php';
?>

<div class="container-fluid mt-4">

<div class="card shadow">
<div class="card-body">

<h3>Resume Penilaian Munaqosah</h3>

<div class="mb-3">

<a href="munaqosah.php"
class="btn btn-secondary">

Kembali

</a>

<a href="export_resume_munaqosah.php"
class="btn btn-success">

Export CSV

</a>

</div>

<div class="alert alert-info">
Semester Aktif: <b><?php echo $semester; ?></b>
</div>

<?php

$kelasList = [

'PAUD',
'1',
'2',
'3',
'4',
'5',
'6',
'7',
'8',
'9',
'10',
'11',
'12',
'Pra Nikah'

];

?>

<ul class="nav nav-tabs mb-3">

<?php
foreach($kelasList as $kelas){
?>

<li class="nav-item">

<a

class="nav-link
<?php
echo
($kelasAktif==$kelas)
? 'active'
: '';
?>

"

href="
resume_munaqosah.php?kelas=
<?php echo urlencode($kelas); ?>

">

<?php echo $kelas; ?>

</a>

</li>

<?php } ?>

</ul>

<div class="table-responsive">

<table class="table table-bordered table-striped">

<thead class="table-dark">

<tr>

<th>NIS</th>

<th>Nama</th>

<th>Desa</th>

<th>Kelompok</th>

<th>Progress</th>

<th>%</th>

<th>Total Nilai</th>

<th>Rata-rata</th>

</tr>

</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($query)) { ?>



<?php
$totalTerisi =

$row['total_terisi']
+
$row['total_kepribadian'];
$progress =
$totalTerisi
. " / " .
$row['total_materi'];

$persen = 0;

if($row['total_materi'] > 0){

    $persen =
    round(

($totalTerisi /
$row['total_materi'])
* 100,

    2

    );
}

?>
<tr>

<td>
<?php echo $row['nis']; ?>
</td>

<td>
<?php echo $row['nama_santri']; ?>
</td>

<td>
<?php echo $row['desa']; ?>
</td>

<td>
<?php echo $row['kelompok']; ?>
</td>

<td>

<?php
echo $progress;
?>

</td>

<td>

<div class="progress">

<div
class="progress-bar bg-success"

style="
width:
<?php echo $persen; ?>%;
">

<?php echo $persen; ?>%

</div>

</div>

</td>

<td>

<?php
echo round(
$row['total_nilai'],
2
);
?>

</td>

<td>

<?php
echo round(
$row['rata_nilai'],
2
);
?>

</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>
</div>

</div>

<?php include 'templates/footer.php'; ?>