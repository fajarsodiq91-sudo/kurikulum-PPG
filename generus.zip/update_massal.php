<?php

session_start();

include 'config.php';

if($_SESSION['role'] != 'master'){

    die("Tidak punya akses");
}

include 'templates/header.php';

if(isset($_POST['upload'])){

    $field =
    $_POST['field_update'];

    $file =
    $_FILES['file']['tmp_name'];

    $handle =
    fopen($file, "r");

    $berhasil = 0;
    $gagal = 0;

    fgetcsv($handle);

    while(($data = fgetcsv(
    $handle,
    10000,
    ","
    )) !== FALSE){

        $nis =
        mysqli_real_escape_string(
        $conn,
        $data[0]
        );

        $value =
        mysqli_real_escape_string(
        $conn,
        $data[1]
        );

        $allowed = [

            'desa',
            'kelompok',
            'jenis_kelamin',
            'kelas_kbm',
            'kelas_sekolah',
            'status_generus',
            'jenjang_generus',
            'nomor_wa',
            'keterangan'

        ];

        if(!in_array(
        $field,
        $allowed
        )){

            die("Field tidak valid");
        }

        $query = mysqli_query($conn,

        "UPDATE generus

        SET $field='$value'

        WHERE nis='$nis'");

        if($query){

            $berhasil++;

        } else {

            $gagal++;
        }
    }

    echo '

    <div class="alert alert-success">

    Update Massal Selesai

    <br><br>

    Berhasil:
    '.$berhasil.'

    <br>

    Gagal:
    '.$gagal.'

    </div>

    ';
}
?>

<div class="container mt-4">

<div class="card shadow">

<div class="card-body">

<h3 class="mb-4">

Update Massal Berdasarkan NIS

</h3>

<form
method="POST"
enctype="multipart/form-data">

<div class="mb-3">

<label>

Pilih Field Yang Mau Diupdate

</label>

<select
name="field_update"
class="form-control"
required>

<option value="">
Pilih Field
</option>

<option value="desa">
Desa
</option>

<option value="kelompok">
Kelompok
</option>

<option value="jenis_kelamin">
Jenis Kelamin
</option>

<option value="kelas_kbm">
Kelas KBM
</option>

<option value="kelas_sekolah">
Kelas Sekolah
</option>

<option value="status_generus">
Status Generus
</option>

<option value="jenjang_generus">
Jenjang Generus
</option>

<option value="nomor_wa">
Nomor WA
</option>

<option value="keterangan">
Keterangan
</option>

</select>

</div>

<div class="mb-3">

<label>

Upload CSV

</label>

<input
type="file"
name="file"
class="form-control"
accept=".csv"
required>

</div>

<div class="alert alert-info">

Format CSV:

<br><br>

Kolom 1:
NIS

<br>

Kolom 2:
Value Baru

</div>

<button
type="submit"
name="upload"
class="btn btn-primary">

Update Massal

</button>

<a href="dashboard.php"
class="btn btn-secondary">

Kembali

</a>

</form>

</div>

</div>

</div>

<?php
include 'templates/footer.php';
?>