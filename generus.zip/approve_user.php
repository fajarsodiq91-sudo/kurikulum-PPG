<?php
session_start();

include 'config.php';

if($_SESSION['role'] != 'master'){

    die("Tidak punya akses");
}

$id = $_GET['id'];

mysqli_query($conn,

"UPDATE users SET

status_approval='approved'

WHERE id='$id'
");

header("Location: approval_user.php");
?>