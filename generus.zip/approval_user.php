<?php
session_start();

include 'config.php';

if($_SESSION['role'] != 'master'){

    die("Tidak punya akses");

}

include 'templates/header.php';

$query = mysqli_query($conn,
"SELECT * FROM users
ORDER BY id DESC");
?>

<div class="card shadow">

<div class="card-body">

<h3 class="mb-4">

Approval User

</h3>

<div class="table-responsive">

<table class="table table-bordered table-striped">

<tr>

<th>No</th>
<th>Nama</th>
<th>Username</th>
<th>Role</th>
<th>Desa</th>
<th>Kelompok</th>
<th>Status</th>
<th>Aksi</th>

</tr>

<?php
$no = 1;

while($data = mysqli_fetch_assoc($query)){
?>

<tr>

<td>
<?php echo $no++; ?>
</td>

<td>
<?php echo $data['nama']; ?>
</td>

<td>
<?php echo $data['username']; ?>
</td>

<td>
<?php echo $data['role']; ?>
</td>

<td>
<?php echo $data['desa']; ?>
</td>

<td>
<?php echo $data['kelompok']; ?>
</td>

<td>

<?php

if($data['status_approval'] == 'approved'){

    echo '<span class="badge bg-success">
    Approved
    </span>';

} else {

    echo '<span class="badge bg-warning text-dark">
    Pending
    </span>';
}
?>

</td>

<td>

<?php
if($data['status_approval'] == 'pending'){
?>

<a href=
"approve_user.php?id=<?php echo $data['id']; ?>"

class="btn btn-success btn-sm">

Approve

</a>

<?php } ?>

<a href=
"hapus_user.php?id=<?php echo $data['id']; ?>"

class="btn btn-danger btn-sm"

onclick="return confirm('Yakin hapus user?')">

Hapus

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

<a href="dashboard.php"
class="btn btn-secondary">

Kembali Dashboard

</a>

</div>

</div>

<?php
include 'templates/footer.php';
?>