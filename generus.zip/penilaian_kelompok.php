<?php

session_start();

include 'config.php';

$role =
$_SESSION['role'] ?? 'viewer';

if($role == 'viewer'){

    die("Harus login");
}

$kelompok =
$_GET['kelompok'] ?? '';

if($role == 'pjp_kelompok'){

    if($kelompok !=
    $_SESSION['kelompok']){

        die("Tidak punya akses");
    }
}

if($role == 'pjp_desa'){

    $queryCek =
    mysqli_query($conn,

    "SELECT *

    FROM generus
WHERE kelompok='$kelompok'

    LIMIT 1");

    $cek =
    mysqli_fetch_assoc($queryCek);

    if($cek['desa'] !=
    $_SESSION['desa']){

        die("Tidak punya akses");
    }
}

include 'templates/header.php';

$querySetting =
mysqli_query($conn,

"SELECT *

FROM setting_app

LIMIT 1");

$setting = mysqli_fetch_assoc($querySetting);

$semester = $setting['semester_aktif'];
$jenjangAktif = $setting['jenjang_aktif'] ?? '';

$daftarJenjang =
explode(
',',
$jenjangAktif
);

$cariNama =
$_GET['cari_nama']
?? '';

$filterKelas =
$_GET['kelas_kbm']
?? '';

$filterJenjang =
$_GET['jenjang']
?? '';

$where = "
WHERE kelompok='$kelompok'

AND status_generus='Masih Generus'
";

$daftarJenjang = array_filter(array_map('trim', explode(',', $jenjangAktif)));

if(!empty($daftarJenjang)){
    $jenjangList = "'" . implode("','", $daftarJenjang) . "'";
    $where .= " AND jenjang_generus IN ($jenjangList) ";
}

if($cariNama != ''){

    $where .= "

    AND nama_santri LIKE
    '%$cariNama%'
    ";
}

if($filterKelas != ''){

    $where .= "

    AND kelas_kbm='$filterKelas'
    ";
}

if($filterJenjang != ''){

    $where .= "

    AND jenjang_generus='$filterJenjang'
    ";
}

$query =
mysqli_query($conn,

"SELECT *

FROM generus

$where

ORDER BY

kelas_kbm,

nama_santri");

?>

<div class="container-fluid mt-4">

<div class="card shadow">

<div class="card-body">

<h3 class="mb-4">

Penilaian Kelompok:
<?php echo $kelompok; ?>

</h3>

<form
method="GET"
class="row mb-4">

<input
type="hidden"
name="kelompok"

value="<?php echo $kelompok; ?>">

<div class="col-md-4">

<input
type="text"

name="cari_nama"

class="form-control"

placeholder="Cari Nama Generus"

value="<?php
echo $cariNama;
?>">

</div>

<div class="col-md-3">

<select
name="kelas_kbm"
class="form-control">

<option value="">
Semua Kelas KBM
</option>

<?php

$kelasList = [

'PAUD',

'1',

'2',

'3',

'4',

'5',

'6',

'7',

'8',

'9',

'10',

'11',

'12',

'Pra Nikah'

];

foreach($kelasList as $k){

?>

<option
value="<?php echo $k; ?>"

<?php
if($filterKelas == $k)
echo 'selected';
?>>

<?php echo $k; ?>

</option>

<?php } ?>

</select>

</div>



<div class="col-md-2">

<button
type="submit"
class="btn btn-primary w-100">

Filter

</button>

</div>

</form>

<a href="munaqosah.php"
class="btn btn-secondary mb-3">

Kembali

</a>

<div class="table-responsive">

<table
class="table table-bordered
table-striped">

<tr class="table-dark">

<th>No</th>
<th>NIS</th>
<th>Nama Santri</th>
<th>Kelas KBM</th>
<th>Jenjang</th>
<th>Progress</th>
<th>Aksi</th>

</tr>

<?php
$no = 1;

while($data =
mysqli_fetch_assoc($query)){

?>

<?php

$queryTotalMateri =
mysqli_query($conn,

"SELECT COUNT(DISTINCT id)
as total

FROM materi_munaqosah

WHERE

TRIM(semester)=TRIM('$semester')

AND

TRIM(kelas)=TRIM(
'".$data['kelas_kbm']."'
)
");

$totalMateri =
mysqli_fetch_assoc(
$queryTotalMateri
)['total'];

$queryIsiMateri =
mysqli_query($conn,

"SELECT COUNT(DISTINCT materi_id)
as total

FROM nilai_munaqosah

WHERE

nis='".$data['nis']."'

AND semester='$semester'
");

$totalIsiMateri =
mysqli_fetch_assoc(
$queryIsiMateri
)['total'];

$queryIsiKepribadian =
mysqli_query($conn,

"SELECT COUNT(DISTINCT item_penilaian)
as total

FROM detail_kepribadian

WHERE

nis='".$data['nis']."'

AND semester='$semester'
");

$totalIsiKepribadian =
mysqli_fetch_assoc(
$queryIsiKepribadian
)['total'];

/*
=========================
TOTAL KEPRIBADIAN
=========================
*/

$totalKepribadian =
$queryIsiKepribadian;

/*
=========================
TOTAL SEMUA ITEM
=========================
*/

$totalSemua =
$totalMateri;

/*
=========================
TOTAL YANG SUDAH DIISI
=========================
*/

$totalIsiSemua =
$totalIsiMateri
+
$totalIsiKepribadian;

$progress = 0;

if($totalSemua > 0){

$progress =
round(

($totalIsiSemua /
$totalSemua)
* 100,

2

);
}

if($progress > 100){

    $progress = 100;
}

?>

<tr>

<td>
<?php echo $no++; ?>
</td>

<td>
<?php echo $data['nis']; ?>
</td>

<td>
<?php echo $data['nama_santri']; ?>
</td>

<td>
<?php echo $data['kelas_kbm']; ?>
</td>

<td>
<?php echo $data['jenjang_generus']; ?>
</td>

<td width="220">

<div class="progress">

<div
class="progress-bar"

style="
width:
<?php echo $progress; ?>%;
">

<?php
echo $progress;
?>%

</div>

</div>

</td>

<td>

<a href=
"input_nilai.php?id=
<?php echo $data['id']; ?>"

class="btn btn-primary btn-sm">

Input Nilai

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</div>

</div>

<?php
include 'templates/footer.php';
?>