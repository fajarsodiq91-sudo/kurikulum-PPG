<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if(!isset($_SESSION['login'])){

    die("Harus login");

}
include 'config.php';

if(!isset($_SESSION['login'])){
    header("Location: login.php");
}

function generateNIS($conn){

    $tahun = date('y');
    $bulan = date('m');

    $prefix = $tahun.$bulan;

    $query = mysqli_query($conn,
    "SELECT nis FROM generus
    WHERE nis LIKE '$prefix%'
    ORDER BY nis DESC
    LIMIT 1");

    $data = mysqli_fetch_assoc($query);

    if($data){

        $lastNumber = substr($data['nis'], 4, 4);
        $newNumber = $lastNumber + 1;

    } else {

        $newNumber = 1;
    }

    return $prefix . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
}

if(isset($_POST['simpan'])){
    
    $queryNomor = mysqli_query($conn,
"SELECT MAX(nomor) as nomor_terbesar
FROM generus");

$dataNomor =
mysqli_fetch_assoc($queryNomor);

$nomorTerbesar =
$dataNomor['nomor_terbesar'];

$urutan = (int)$nomorTerbesar;

$urutan++;

$nomor = sprintf("%04s", $urutan);

    $desa = $_POST['desa'];
    $kelompok = $_POST['kelompok'];
    $madrasah = $_POST['madrasah'];

    $nis = generateNIS($conn);

    $nama_bapak = $_POST['nama_bapak'];
    $nama_ibu = $_POST['nama_ibu'];
    $pekerjaan_bapak = $_POST['pekerjaan_bapak'];
    $pekerjaan_ibu = $_POST['pekerjaan_ibu'];

    $nomor_wa = $_POST['nomor_wa'];

    $nama_santri = $_POST['nama_santri'];

    $jenis_kelamin = $_POST['jenis_kelamin'];

    $kota_lahir = $_POST['kota_lahir'];

    $tanggal_lahir = $_POST['tanggal_lahir'];

    $anak_ke = $_POST['anak_ke'];

    $dari_saudara = $_POST['dari_saudara'];

    $kelas_sekolah = $_POST['kelas_sekolah'];

    $kelas_kbm = $_POST['kelas_kbm'];

    $status_generus = $_POST['status_generus'];
    
    $jenjang_generus =
$_POST['jenjang_generus'];

$keterangan =
$_POST['keterangan'];

    mysqli_query($conn, "INSERT INTO generus
    (
        nomor,
        desa,
        kelompok,
        madrasah,
        nis,
        nama_bapak,
        nama_ibu,
        pekerjaan_bapak,
        pekerjaan_ibu,
        nomor_wa,
        nama_santri,
        jenis_kelamin,
        kota_lahir,
        tanggal_lahir,
        anak_ke,
        dari_saudara,
        kelas_sekolah,
        kelas_kbm,
        jenjang_generus,
        status_generus,
        keterangan
    )

    VALUES

    (
        '$nomor',
        '$desa',
        '$kelompok',
        '$madrasah',
        '$nis',
        '$nama_bapak',
        '$nama_ibu',
        '$pekerjaan_bapak',
        '$pekerjaan_ibu',
        '$nomor_wa',
        '$nama_santri',
        '$jenis_kelamin',
        '$kota_lahir',
        '$tanggal_lahir',
        '$anak_ke',
        '$dari_saudara',
        '$kelas_sekolah',
        '$kelas_kbm',
        '$jenjang_generus',
        '$status_generus',
        '$keterangan'
    )
    ");

header("Location: data_generus.php");
exit;

}
?>

<?php
include 'templates/header.php';
?>

<div class="card shadow">

<div class="card-body">

<h3 class="mb-4">
Tambah Data Generus
</h3>

<h2>Tambah Data Generus</h2>

<form
method="POST"
autocomplete="off">

<div class="mb-3">

<label>
Desa
<span class="text-danger">*</span>
</label>
<select name="desa" class="form-control" required id="desa" onchange="updateKelompok()">

<option value="">
Pilih desa
</option>

</div>

<option value="">Pilih Desa</option>

<option value="Adiarsa Timur">Adiarsa Timur</option>
<option value="Klari">Klari</option>
<option value="Lemah Mulya">Lemah Mulya</option>
<option value="Tunggak Jati">Tunggak Jati</option>

</select>

<br><br>

<div class="mb-3">

<label>
Kelompok
<span class="text-danger">*</span>
</label>

<select name="kelompok" id="kelompok" class="form-control" required>

<option value="">
Pilih Kelompok
</option>

</select>

</div>

Madrasah<br>
<input type="text" name="madrasah" class="form-control"><br><br>

Nama Bapak<br>
<input type="text" name="nama_bapak" class="form-control"><br><br>

Nama Ibu<br>
<input type="text" name="nama_ibu" class="form-control"><br><br>

Pekerjaan Bapak<br>
<input type="text" name="pekerjaan_bapak" class="form-control"><br><br>

Pekerjaan Ibu<br>
<input type="text" name="pekerjaan_ibu" class="form-control"><br><br>

Nomor WA<br>
<input type="text" name="nomor_wa" class="form-control"><br><br>

Nama Santri <span class="text-danger">*</span> <br>
<input type="text" name="nama_santri" class="form-control" required><br><br>

Jenis Kelamin <span class="text-danger">*</span> <br>
<select name="jenis_kelamin" class="form-control" required>
    
<option value="">
Pilih jenis kelamin
</option>

<option value="Laki-Laki">Laki-Laki</option>
<option value="Perempuan">Perempuan</option>

</select>

<br><br>

Kota Lahir<br>
<input type="text" name="kota_lahir" class="form-control"><br><br>

Tanggal Lahir<br>
<input type="date" name="tanggal_lahir" class="form-control"><br><br>

Anak ke<br>
<input type="number" name="anak_ke" class="form-control"><br><br>

Dari Berapa Saudara<br>
<input type="number" name="dari_saudara" class="form-control"><br><br>

Kelas di Sekolah<br>
<select name="kelas_sekolah" class="form-control">
    
<option value="">
Pilih kelas sekolah
</option>

<option value="Pra PAUD">Pra PAUD</option>
<option value="PAUD">PAUD</option>
<option value="TK">TK</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="Mahasiswa">Mahasiswa</option>
<option value="-">-</option>

</select>

<br><br>

Kelas di KBM  <span class="text-danger">*</span> <br>
<select name="kelas_kbm" class="form-control" required>
    
<option value="">
Pilih kelas KBM
</option>

<option value="Pra PAUD">Pra PAUD</option>
<option value="PAUD">PAUD</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="Pra Nikah">Pra Nikah</option>

</select>

<br><br>

<div class="mb-3">

<label>

Jenjang Generus
<span class="text-danger">*</span>

</label>

<select
name="jenjang_generus"
class="form-control"
required>

<option value="">
Pilih Jenjang
</option>

<option value="Pra PAUD">
Pra PAUD
</option>

<option value="PAUD">
PAUD
</option>

<option value="Caberawit">
Caberawit
</option>

<option value="Pra Remaja">
Pra Remaja
</option>

<option value="Remaja">
Remaja
</option>

<option value="Pra Nikah">
Pra Nikah
</option>

</select>

</div>

Status Generus<br>
<select name="status_generus" class="form-control" required>

<option value="">
Pilih status generus
</option>

<option value="Masih Generus">Masih Generus</option>
<option value="Pindah Sambung">Pindah Sambung</option>
<option value="Sudah Menikah">Sudah Menikah</option>

</select>

<br><br>

<div class="mb-3">

<label>
Keterangan
</label>

<textarea
name="keterangan"
class="form-control"
rows="3"></textarea>

</div>

<button type="submit"
name="simpan"
class="btn btn-primary">

Simpan Data

</button>

<a href="dashboard.php"
class="btn btn-secondary">

Kembali Dashboard

</a>

</form>

<script>

function updateKelompok(){

    let desa =
    document.getElementById("desa").value;

    let kelompok =
    document.getElementById("kelompok");

    let data = {

        "Adiarsa Timur": [
            "Babakan Jati 1",
            "Babakan Jati 2",
            "Karawang Kota 1",
            "Karawang Kota 2",
            "Wadas",
            "Wirasaba"
        ],

        "Klari": [
            "Belendung",
            "Cibalongsari 1",
            "Cibalongsari 2",
            "Cirejag",
            "Kalimulya",
            "Pancawati"
        ],

        "Lemah Mulya": [
            "Anggadita",
            "CKM 1",
            "CKM 2",
            "HNH",
            "Tamiang 1",
            "Tamiang 2",
            "Karawang Megah",
            "Tipar"
        ],

        "Tunggak Jati": [
            "Kalang Surya",
            "Pakis",
            "Tanjung Baru Barat",
            "Tanjung Baru Timur",
            "Tunggak Jati"
        ]
    };

    kelompok.innerHTML =
    '<option value="">Pilih Kelompok</option>';

    if(data[desa]){

        data[desa].forEach(function(item){

            let option =
            document.createElement("option");

            option.value = item;

            option.text = item;

            kelompok.appendChild(option);

        });
    }
}

</script>

</div>

</div>

<?php
include 'templates/footer.php';
?>