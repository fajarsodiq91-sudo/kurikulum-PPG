<?php

include 'config.php';

header('Content-Type: text/csv');

header(
'Content-Disposition:
attachment;
filename="nilai_munaqosah.csv"');

$output =
fopen("php://output", "w");

fputcsv($output,[

'NIS',
'Nama',
'Desa',
'Kelompok',
'Semester',
'Kategori',
'Bab',
'Materi',
'Nilai',
'Catatan'

]);

$query = mysqli_query($conn, "

SELECT

nm.nis,
g.nama_santri,
nm.desa,
nm.kelompok,
nm.semester,
nm.kategori,
nm.bab,
nm.materi,
nm.nilai,
'' AS catatan

FROM nilai_munaqosah nm

LEFT JOIN generus g
ON g.nis = nm.nis

UNION ALL

SELECT

dk.nis,
g.nama_santri,
g.desa,
g.kelompok,
dk.semester,
'KEPRIBADIAN' AS kategori,
'' AS bab,
dk.item_penilaian AS materi,
dk.nilai,
dk.catatan

FROM detail_kepribadian dk

LEFT JOIN generus g
ON g.nis = dk.nis

ORDER BY desa, kelompok, semester, kategori

");

while($data =
mysqli_fetch_assoc($query)){

    fputcsv($output,[

    $data['nis'],

    $data['nama_santri'],

    $data['desa'],

    $data['kelompok'],

    $data['semester'],

    $data['kategori'],

    $data['bab'],

    $data['materi'],

    $data['nilai'],
    
    $data['catatan']

    ]);
}

fclose($output);
exit;
?>